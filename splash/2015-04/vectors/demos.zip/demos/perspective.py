'''
A demo to show how weird things look if we use orthographic projection
(just chopping off the Z axis) to put 3-D scenes on a 2-D screen.

Adapted from the Bump Mapping demo that comes with Panda3D; see
  https://www.panda3d.org/download/panda3d-1.8.1/panda3d-1.8.1-samples.zip
for the original.
'''

import sys,os
from splash import *

from panda3d.core import loadPrcFileData
# Configure the parallax mapping settings (these are just the defaults)
loadPrcFileData("", "parallax-mapping-samples 3")
loadPrcFileData("", "parallax-mapping-scale 0.1")

# Function to put instructions on the screen.
def addInstructions(pos, msg):
    return OnscreenText(text=msg, style=1, fg=(1,1,1,1),
                        pos=(-1.3, pos), align=TextNode.ALeft, scale = .05)

# Function to put title on the screen.
def addTitle(text):
    return OnscreenText(text=text, style=1, fg=(1,1,1,1),
                        pos=(1.3,-0.95), align=TextNode.ARight, scale = .07)


class PerspectiveDemo(object):
    def __init__(self):
        # Check video card capabilities.
        if (base.win.getGsg().getSupportsBasicShaders() == 0):
            addInstructions(0.75, "Bump Mapping: Video driver reports that shaders are not supported.")
            self.shaderenable = 0
        else:
            self.shaderenable = 1

        # Post the instructions
        self.title = addTitle("Perspective Demo")
        self.inst1 = addInstructions(0.95, "Press ESC to exit")
        self.inst2 = addInstructions(0.90, "Move mouse to rotate camera")
        self.inst3 = addInstructions(0.85, "W/S/A/D: Move camera")
        self.inst4 = addInstructions(0.80, "Space: Toggle perspective/orthographic camera")
        if self.shaderenable == 1:
            self.inst5 = addInstructions(0.75, "Enter: Turn bump maps Off")

        # Load the 'abstract room' model.  This is a model of an
        # empty room containing a pillar, a pyramid, and a bunch
        # of exaggeratedly bumpy textures.
        self.room = Object("models/abstractroom")

        hide_mouse()

        # Set up the default and orthographic cameras
        self.isortho = False
        self.defaultLens = camera.lens
        self.orthoLens = OrthographicLens()
        self.orthoLens.setFilmSize(40, 30)

        on("escape", sys.exit, [0])
        if self.shaderenable == 1:
            on("enter", self.toggleShader)
        on("space", self.toggleOrtho)

        # Add a light to the scene.
        self.lightpivot = Node("lightpivot")
        self.lightpivot.pos = Vec3(0, 0, 25)
        self.lightpivot.np.hprInterval(10, Point3(360, 0, 0)).loop()
        plight = PointLight('plight')
        plight.pos = Vec3(45, 0, 0)
        plight.color = Vec4(1, 1, 1, 1)
        plight.attenuation = Vec3(0.7,0.05,0)
        self.room.illuminate(plight)

        self.room.setShaderInput("light", plight.np)

        # Add an ambient light
        alight = AmbientLight('alight')
        alight.color = Vec4(0.2, 0.2, 0.2, 1)
        self.room.illuminate(alight)

        # create a sphere to denote the light
        sphere = Object("models/sphere")
        plight.attach(sphere)
        self.lightpivot.attach(plight)

        if self.shaderenable == 1:
            # load and apply the shader.  This is using panda's
            # built-in shader generation capabilities to create the
            # shader for you.  However, if desired, you can supply
            # the shader manually.  Change this line of code to:
            #   self.room.setShader(Shader.load("bumpMapper.sha"))
            self.room.setShaderAuto()

    def toggleOrtho(self):
        # Change to an orthographic projection
        self.isortho = not self.isortho
        if self.isortho:
            camera.lens = self.orthoLens
        else:
            camera.lens = self.defaultLens

    def toggleShader(self):
        self.inst5.destroy()
        if (self.shaderenable):
            self.inst5 = addInstructions(0.75, "Enter: Turn bump maps On")
            self.shaderenable = 0
            self.room.setShaderOff()
        else:
            self.inst5 = addInstructions(0.75, "Enter: Turn bump maps Off")
            self.shaderenable = 1
            self.room.setShaderAuto()


PerspectiveDemo()
training_wheels()
run()
