'''
This is the teapot game as we wrote it in Saturday's section.
See teapot_full.py for a more complete reference, with notes
and some bonus code.
'''

from splash import *

def setup():
    teapot = Object('models/teapot')
    terrain = Object('models/world')
    sky = Skybox('models/sky_#.jpg')
    
    ambient = AmbientLight('ambient')
    ambient.color = Vec4(0.5, 0.5, 0.25, 1)
    sun = DirectionalLight('sun')
    sun.color = Vec4(1, 1, 0.5, 1)
    sun.direction = Vec3(-1, -1, -1)
    teapot.pos = Vec3(0, 0, 5)
    
    teapot.forward = Vec3(1, 0, 0)
    teapot.left = Vec3(0, 1, 0)
    UP = Vec3(0, 0, 1)
    
    camera.pos = teapot.pos - teapot.forward * 20 + UP * 5
    camera.lookAt(teapot)
    
    TEAPOT_SPEED = 5
    
    def move_teapot(t):
        distance = TEAPOT_SPEED * t
        if button.is_down('w'):
            teapot.pos = teapot.pos + teapot.forward * \
                         distance
        if button.is_down('s'):
            teapot.pos = teapot.pos - teapot.forward * \
                         distance
        if button.is_down('a'):
            teapot.pos = teapot.pos + teapot.left * \
                         distance
        if button.is_down('d'):
            teapot.pos = teapot.pos - teapot.left * \
                         distance
                     
    
    always(move_teapot)

setup()
run()
