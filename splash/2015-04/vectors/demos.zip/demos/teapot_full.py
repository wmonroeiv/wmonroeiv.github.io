'''
This is my full-featured version of our Journeys of a Teapot game, with
a few extra pieces we didn't get to in class. If you want to see the
exact code we wrote in each of the two sections, check out the other
two files, teapot_sec1.py (Saturday's class) and teapot_sec2.py (Sunday).

This code is written in Python using a library called Panda3D:

  https://www.panda3d.org

On Windows and Mac, you can download the SDK and run the code immediately:

  https://www.panda3d.org/download.php?sdk&version=1.8.1

[On Linux, it might take a few tries; I would recommend getting the very
latest "devel" ("likely to be unstable!") snapshot, since the pre-built
packages are very out-of-date. You'll probably want to install Python
first, and I'd highly recommend installing Pip while you're at it:

  https://www.python.org/downloads/release/python-279/
  https://pip.pypa.io/en/stable/installing.html ]

Those of you who are new to Python but have programmed before should find
the official Python tutorial reasonably easy to follow:

  https://docs.python.org/2/tutorial/

Once you feel okay about Python, the next step is figuring out Panda3D.
I wrote quite a bit of code in splash.py to make sure the library
stayed out of our way for the class, but you'll probably want to figure
out the real deal:

  https://www.panda3d.org/manual/index.php/Starting_Panda3D

It might take a while to learn, but don't be scared--keep at it and you'll
soon be able to do all the stuff we did in this class and much more. If
you want to know exactly how to do something we did in this class in real
Panda3D, you can take a look at splash.py for the "behind-the-scenes" code.

A number of people in the class had instead programmed in Java before. If
you'd prefer to stick to the comfort of Java, you might like jMonkey:

  http://wiki.jmonkeyengine.org/doku.php
'''

from splash import *
from sys import exit

def setup():
    # Add our teapot and a world for it to inhabit.
    terrain = Object('models/world')
    sky = Skybox('models/sky_#.jpg')
    teapot = Object('models/teapot')
    
    # Set up light sources:
    # - minimum level of light so everything is visible
    ambient = AmbientLight('ambient')
    ambient.color = Vec4(0.4, 0.4, 0.2, 1)
    # - sunlight from a particular direction for realism
    sun = DirectionalLight('sun')
    sun.color = Vec4(1, 1, 0.5, 1)
    sun.direction = Vec3(-1, -1, -1)

    # Establish the position and important directions for the teapot.
    teapot.pos = Vec3(0, 0, 5)
    teapot.forward = Vec3(1, 0, 0)
    teapot.left = Vec3(0, 1, 0)
    UP = Vec3(0, 0, 1)

    # BONUS STUFF: setting the teapot on the ground
    # We can do this using a library for collision detection: shoot a ray downward
    # from way up above the teapot and see where it hits the ground. Then set the
    # teapot's z position to that point. More where we use this below.
    ray = CollisionRay('ground_ray')
    ray.direction = Vec3(0, 0, -1)

    #ray.visualize()
    #teapot.transparency = TransparencyAttrib.MAlpha
    #teapot.color = Vec4(1, 1, 1, 0.5)

    def control_teapot(t):
        if button.is_down('w'):
            teapot.pos += teapot.forward * 20 * t
        if button.is_down('s'):
            teapot.pos -= teapot.forward * 20 * t
        if button.is_down('a'):
            # teapot.pos += teapot.left * 20 * t

            # BONUS STUFF: rotation
            # In many games the left/right buttons turn the character
            # rather than having the character glide to the left. We
            # can do that changing the forward vector rather than the
            # position, and then using lookAt (below) to face forward.
            teapot.forward += teapot.left * t
        if button.is_down('d'):
            # teapot.pos -= teapot.left * 20 * t
            teapot.forward -= teapot.left * t
        
        # It's generally important to keep vectors that are used to
        # represent directions at length 1. This way, you can take dot
        # products with them and not worry about dividing by lengths.
        # The code to set a vector's length to 1 looks like this:
        #   vec = vec / vec.length()
        # where vec.length() is sqrt(x^2 + y^2 + z^2). However, setting
        # a vector to length 1 is so common that there's a pre-made
        # method you can just call: normalize().
        teapot.forward.normalize()
        # We could change the teapot's left vector at the same time we
        # adjust its forward vector if we wanted, but since we have
        # forward and up, why not use the cross product to compute left
        # for us?
        teapot.left = Vec3(0, 0, 1).cross(teapot.forward)
        teapot.left.normalize()

        # BONUS STUFF
        # Here is where we actually use the ray we created above.
        # First we move the ray to start above the teapot:
        ray.origin = teapot.pos + Vec3(0, 0, 1000)
        # Then we actually ask the game engine to tell us if it hits anything:
        collisions = ray.detectCollisions()
        if len(collisions) != 0:
            # If we have a ground to rest on, put us there.
            teapot.z = collisions[0].point.z
            
            # We also might want our teapot to orient itself so it actually
            # follows the slope of the land, rather than always magically
            # hovering perfectly level. The collision engine gives us the
            # normal vector for the terrain. Thus, the direction we want the
            # teapot to actually look is perpendicular to both the
            # terrain (so the teapot is flat on the ground) and the teapot's
            # left vector (so the teapot is still facing the same compass
            # direction, just tilted).
            look_vector = teapot.left.cross(collisions[0].normal)
            look_vector.normalize()

            # By specifying not just a point to look at but also a direction
            # that is up, we can give the teapot all sorts of weird
            # orientations. Here, we can specify that up is not the Z axis
            # but instead perpendicular to the actual terrain surface.
            teapot.lookAt(teapot.pos + look_vector, up=collisions[0].normal)

            # Note: Setting the orientation (rotation) of an object using its forward
            # and left directions and the lookAt method works, but it is actually not
            # the normal way video game programmers do it. The easiest way is to set the
            # object's Euler angles:
            #   http://en.wikipedia.org/wiki/Euler_angles
            # In Panda3D, these angles are called
            # - heading (think east/north/south/west)
            # - pitch (uphill/downhill)
            # - roll (the direction a confused dog tilts its head)
            # and they can be changed by calling an object's (NodePath's) setHpr method.
        else:
            # If we roam off the terrain, we still want to be able to
            # control the teapot's rotation, so let's just set the teapot
            # upright until (and if) it gets back to land.
            teapot.lookAt(teapot.pos + teapot.forward, up=Vec3(0, 0, 1))

        # Position and orient the camera relative to the teapot
        camera.pos = teapot.pos + UP * 5 - teapot.forward * 20
        camera.lookAt(teapot)

    # Every frame, call the function control_teapot, passing it the length of
    # time that has elapsed since the last frame.
    always(control_teapot)
    # Quit if we hit the Esc key.
    on('escape', exit)


setup()
run()
