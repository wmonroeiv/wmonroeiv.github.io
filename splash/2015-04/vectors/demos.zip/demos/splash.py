'''
A wrapper library for Panda3D for teaching purposes. The main
changes that make this library different from Panda3D are:

  - Special objects that tie together the PandaNode and NodePath
    classes, so you don't have to worry about which one you need
    for a particular method call.

  - Getter and setter methods are replaced by Python properties,
    so you can write
      >>> obj.pos
    and
      >>> obj.pos = Vec3(0, 0, 5)
    instead of
      >>> obj.getPos()
      >>> obj.setPos(0, 0, 5)

  - Simplified method and object names for registering keyboard events
    ("on" for "base.accept"), creating tasks ("always" for "taskMgr.add"),
    and referring to the most important built-in objects ("world" for
    "render" and "camera" for "base.camera/base.cam").
'''

import panda3d.core

from direct.showbase.ShowBase import ShowBase
from panda3d.core import *
from direct.task.Task import Task
from direct.actor.Actor import Actor
from direct.gui.OnscreenText import OnscreenText
from direct.showbase.DirectObject import DirectObject
from direct.filter.CommonFilters import *


ShowBase()

'''
=================================================
init_properties, NPProxy, and NodeWrappedProxy are a lot of Python dark magic
that accomplish the transformation from getters/setters (getPos, setColor) to
properties (obj.pos, obj.color = ...). You can mostly ignore these, but if you
get a mysterious Python error saying something is an NPProxy or a
NodeWrappedProxy when you need a PandaNode or a NodePath, you'll need to
access the Panda objects directly. You can do this with the obj.np field for
a NodePath, or the obj.actual field for a PandaNode.
=================================================
'''
def init_properties(proxy_class, target_class, delegate):
    for field in dir(target_class):
        if not field.startswith('_'):
            setattr(proxy_class, field, delegate(getattr(target_class, field)))

    for field in dir(target_class):
        if field.startswith('get_'):
            getter = delegate(getattr(target_class, field))
            basename = field[len('get_'):]
            if 'set_' + basename in dir(target_class):
                setter = delegate(getattr(target_class, 'set_' + basename))
                setattr(proxy_class, basename, property(getter, setter))
            else:
                setattr(proxy_class, basename, property(getter))


class NPProxy(object):
    def __init__(self, node_path):
        self.np = node_path

    def attach(self, obj):
        obj.np.reparentTo(self.np)

    def illuminate(self, light):
        render.clearLight(light.np)
        self.np.setLight(light.np)

    @staticmethod
    def delegate(real_method):
        def method(self, *args, **kwargs):
            args = [a.np if isinstance(a, NPProxy) else a for a in args]
            kwargs = {kw: (a.np if isinstance(a, NPProxy) else a)
                      for kw, a in kwargs.iteritems()}
            return real_method(self.np, *args, **kwargs)
        return method

init_properties(NPProxy, NodePath, NPProxy.delegate)


class NodeWrappedProxy(NPProxy):
    def __init__(self, node_path, actual):
        NPProxy.__init__(self, node_path)
        self.actual = actual

    @staticmethod
    def delegate_actual(real_method):
        def method(self, *args, **kwargs):
            args = [a.np if isinstance(a, NPProxy) else a for a in args]
            kwargs = {kw: (a.np if isinstance(a, NPProxy) else a)
                      for kw, a in kwargs.iteritems()}
            return real_method(self.actual, *args, **kwargs)
        return method

'''
=================================================
Here we define all of the actual wrapper classes that might be useful.
This is a very incomplete list. If you want to make an actual game, you'll
find that these types of objects aren't enough, and you'll want the rest of
Panda3D as well. You can either try to copy these classes and extend the
library--let me know if you try this!--or more realistically, just learn
how to use the real library to make games.
=================================================
'''
class Camera(NodeWrappedProxy):
    def __init__(self, camera, cam):
        NodeWrappedProxy.__init__(self, camera, cam.node())

init_properties(Camera, panda3d.core.Camera, NodeWrappedProxy.delegate_actual)
init_properties(Camera, NodePath, NodeWrappedProxy.delegate)


class PointLight(NodeWrappedProxy):
    def __init__(self, name):
        light = panda3d.core.PointLight(name)
        lnp = render.attachNewNode(light)
        render.setLight(lnp)
        NodeWrappedProxy.__init__(self, lnp, light)

init_properties(PointLight, NodePath, NodeWrappedProxy.delegate)
init_properties(PointLight, panda3d.core.PointLight, NodeWrappedProxy.delegate_actual)


class AmbientLight(NodeWrappedProxy):
    def __init__(self, name):
        light = panda3d.core.AmbientLight(name)
        lnp = render.attachNewNode(light)
        render.setLight(lnp)
        NodeWrappedProxy.__init__(self, lnp, light)

init_properties(AmbientLight, NodePath, NodeWrappedProxy.delegate)
init_properties(AmbientLight, panda3d.core.AmbientLight, NodeWrappedProxy.delegate_actual)


class DirectionalLight(NodeWrappedProxy):
    def __init__(self, name):
        light = panda3d.core.DirectionalLight(name)
        lnp = render.attachNewNode(light)
        render.setLight(lnp)
        NodeWrappedProxy.__init__(self, lnp, light)

init_properties(DirectionalLight, NodePath, NodeWrappedProxy.delegate)
init_properties(DirectionalLight, panda3d.core.DirectionalLight, NodeWrappedProxy.delegate_actual)


class Collision(object):
    def __init__(self, point, normal):
        self.point = point
        self.normal = normal


class CollisionRay(NodeWrappedProxy):
    def __init__(self, name):
        self.ray = panda3d.core.CollisionRay()
        self.colNode = CollisionNode(name)
        self.colNodeNp = render.attachNewNode(self.colNode)
        NodeWrappedProxy.__init__(self, self.colNodeNp, self.ray)

        self.cTrav = CollisionTraverser()
        self.queue = CollisionHandlerQueue()

        self.colNode.addSolid(self.ray)
        self.cTrav.addCollider(self.colNodeNp, self.queue)

    def detectCollisions(self):
        self.cTrav.traverse(render)
        return [Collision(c.getSurfacePoint(render),
                          c.getSurfaceNormal(render))
                for c in self.queue.getEntries()]
    
    def visualize(self):
        self.colNodeNp.show()
        self.cTrav.showCollisions(render)

init_properties(CollisionRay, NodePath, NodeWrappedProxy.delegate)
init_properties(CollisionRay, panda3d.core.CollisionRay, NodeWrappedProxy.delegate_actual)


class Object(NPProxy):
    def __init__(self, model_file):
        model = loader.loadModel(model_file)
        NPProxy.__init__(self, model)
        model.reparentTo(render)


SKYBOX_MODEL = 'models/skybox'
class Skybox(Object):
    def __init__(self, image_pattern):
        Object.__init__(self, SKYBOX_MODEL)
        self.init_textures(image_pattern)
        self.setScale(512)
        self.setBin('background', 1)
        self.setDepthWrite(0)
        self.setLightOff()
        self.reparentTo(base.camera)
        self.setCompass()

    def init_textures(self, image_pattern):
        DIRS = ['down', 'up', 'east', 'south', 'west', 'north']
        for dir_name in DIRS:
            tex = loader.loadTexture(image_pattern.replace('#', dir_name))
            tex.setWrapU(Texture.WM_clamp)
            tex.setWrapV(Texture.WM_clamp)
            self.find('**/' + dir_name).setTexture(tex)


class Node(NPProxy):
    def __init__(self, name):
        np = render.attachNewNode(name)
        NPProxy.__init__(self, np)


'''
=================================================
Finally, I included some general-purpose functions that I wanted to be
very simple to write: a simplified event/task system (using "on" and "always"
rather than base.accept and taskMgr.add), and an easy way to read the keyboard
and mouse, and a default keyboard/mouse control for the camera so we could get
our bearings at the beginning of the class.
=================================================
'''
class DefaultCameraControl(DirectObject):
    FORWARD = 0
    BACK = 1
    LEFT = 2
    RIGHT = 3

    def __init__(self):
        # Set the current viewing target
        self.focus = Vec3(55,-55,20)
        self.heading = 180
        self.pitch = 0
        self.mousex = 0
        self.mousey = 0
        self.last = 0
        self.motion = [False, False, False, False]

        self.task = taskMgr.add(self.controlCamera, 'camera-task')

        self.accept('w', self.setMotion, [self.FORWARD, True])
        self.accept('w-up', self.setMotion, [self.FORWARD, False])
        self.accept('s', self.setMotion, [self.BACK, True])
        self.accept('s-up', self.setMotion, [self.BACK, False])
        self.accept('a', self.setMotion, [self.LEFT, True])
        self.accept('a-up', self.setMotion, [self.LEFT, False])
        self.accept('d', self.setMotion, [self.RIGHT, True])
        self.accept('d-up', self.setMotion, [self.RIGHT, False])

    def setMotion(self, direction, enable):
        self.motion[direction] = enable

    def controlCamera(self, task):
        # figure out how much the mouse has moved (in pixels)
        md = base.win.getPointer(0)
        x = md.getX()
        y = md.getY()
        if base.win.movePointer(0, 100, 100):
            self.heading = self.heading - (x - 100) * 0.2
            self.pitch = self.pitch - (y - 100) * 0.2
        if (self.pitch < -45): self.pitch = -45
        if (self.pitch >  45): self.pitch =  45
        base.camera.setHpr(self.heading,self.pitch,0)
        forward = base.camera.getMat().getRow3(1)
        right = base.camera.getMat().getRow3(0)
        elapsed = task.time - self.last
        if (self.last == 0): elapsed = 0

        if (self.motion[self.FORWARD]):
            self.focus = self.focus + forward * elapsed * 30
        if (self.motion[self.BACK]):
            self.focus = self.focus - forward * elapsed * 30
        if (self.motion[self.LEFT]):
            self.focus = self.focus - right * elapsed * 30
        if (self.motion[self.RIGHT]):
            self.focus = self.focus + right * elapsed * 30

        base.camera.setPos(self.focus - (forward * 5))
        self.last = task.time
        return Task.cont


class TaskTimer(object):
    def __init__(self, func):
        self.func = func
        self.last = None

    def __call__(self, task):
        if self.last is None:
            dt = 0
        else:
            dt = task.time - self.last
        self.last = task.time
        ret_code = self.func(dt)
        if ret_code in (Task.done, Task.again):
            return ret_code
        else:
            return Task.cont


class Buttons(object):
    '''
    Easy polling interface for reading the keyboard and mouse.

    Thanks to Panda3D forums user ynjh_jo for the implementation:
    https://www.panda3d.org/forums/viewtopic.php?t=4331
    '''
    def is_down(self, key):
        if len(key) == 1:
            button = KeyboardButton.asciiKey(key)
        else:
            if key == 'del': key = '_del'
            if hasattr(KeyboardButton, key):
                button = getattr(KeyboardButton, key)()
            else:
                button = getattr(MouseButton, key)()
        return base.mouseWatcherNode.isButtonDown(button)

button = Buttons()


on = base.accept

def always(task_func, task_name=None):
    if task_name is None:
        task_name = task_func.__name__
    taskMgr.add(TaskTimer(task_func), task_name)


def hide_mouse():
    # Make the mouse invisible
    props = WindowProperties()
    props.setCursorHidden(True)
    base.win.requestProperties(props)


def set_title(title):
    props = WindowProperties()
    props.setTitle('Demo')
    base.win.requestProperties(props)


def training_wheels():
    hide_mouse()
    DefaultCameraControl()
    on('escape', sys.exit)


base.disableMouse()
set_title('Demo')

run = base.run
camera = Camera(base.camera, base.cam)
world = NPProxy(render)

