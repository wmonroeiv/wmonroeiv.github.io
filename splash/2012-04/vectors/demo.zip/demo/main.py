# A demo of Euler's method for numerical integration:
# "Launching snowballs"
# Created from the "bump mapping" tutorial demo for Panda3D

from panda3d.core import loadPrcFileData

import direct.directbase.DirectStart
from panda3d.core import WindowProperties
from panda3d.core import Filename,Shader
from panda3d.core import AmbientLight,PointLight
from panda3d.core import TextNode
from panda3d.core import OrthographicLens
from panda3d.core import Point3,Vec3,Vec4
from direct.task.Task import Task
from direct.actor.Actor import Actor
from direct.gui.OnscreenText import OnscreenText
from direct.showbase.DirectObject import DirectObject
from direct.filter.CommonFilters import *
import sys,os

# Function to put title on the screen.
def addTitle(text):
	return OnscreenText(text=text, style=1, fg=(1,1,1,1),
						pos=(1.3,-0.95), align=TextNode.ARight, scale = .07)

class EulerDemo(DirectObject):

	def __init__(self):

		base.win.setClearColor(Vec4(0,0,0,1))
		
		self.room = loader.loadModel("models/world")
		self.room.reparentTo(render)

		# Make the mouse invisible, turn off normal mouse controls
		base.disableMouse()
		props = WindowProperties()
		props.setCursorHidden(True)
		base.win.requestProperties(props)

		# Set the current viewing target
		self.focus = Vec3(-20,20,20)
		self.heading = 180
		self.pitch = 0
		self.mousex = 0
		self.mousey = 0
		self.last = 0
		self.mousebtn = [0,0,0]
		
		# Start the camera control task:
		taskMgr.add(self.controlCamera, "camera-task")
		self.accept("escape", sys.exit, [0])
		self.accept("mouse1", self.fireSnowball, [])
		
		# Add an ambient light
		alight = AmbientLight('alight')
		alight.setColor(Vec4(0.4, 0.4, 0.4, 1))
		alnp = render.attachNewNode(alight)
		self.room.setLight(alnp)

		self.snowballs = []
		self.updateTask = taskMgr.add(self.updateSnowballs, 'UpdateSnowballs')
		self.oldTaskTime = 0
		
	def fireSnowball(self):
		newBallPivot = render.attachNewNode("newBallPivot" + str(len(self.snowballs)))
		dir = base.camera.getMat().getRow3(1)
		newBallPivot.setPos(base.camera.getPos() + dir * 4)
		newBall = loader.loadModel("models/sphere")
		newBall.reparentTo(newBallPivot)
		self.snowballs.append({'node': newBallPivot, 'vel': dir * 100})
	
	def updateSnowballs(self, task):
		frameTime = task.time - self.oldTaskTime

		gravity = Vec3(0, 0, -9.8) * 5
		for snowball in self.snowballs:
			snowball['vel'] = snowball['vel'] + gravity * frameTime
			snowball['node'].setPos(snowball['node'].getPos() + snowball['vel'] * frameTime)
		
		self.oldTaskTime = task.time
		return task.cont

	def controlCamera(self, task):
		# figure out how much the mouse has moved (in pixels)
		md = base.win.getPointer(0)
		x = md.getX()
		y = md.getY()
		if base.win.movePointer(0, 100, 100):
			self.heading = self.heading - (x - 100) * 0.2
			self.pitch = self.pitch - (y - 100) * 0.2
		if (self.pitch < -45): self.pitch = -45
		if (self.pitch >  45): self.pitch =  45
		base.camera.setHpr(self.heading,self.pitch,0)
		dir = base.camera.getMat().getRow3(1)
		elapsed = task.time - self.last
		if (self.last == 0): elapsed = 0
		base.camera.setPos(self.focus - (dir*5))
		if (base.camera.getX() < -59.0): base.camera.setX(-59)
		if (base.camera.getX() >  59.0): base.camera.setX( 59)
		if (base.camera.getY() < -59.0): base.camera.setY(-59)
		if (base.camera.getY() >  59.0): base.camera.setY( 59)
		if (base.camera.getZ() <   5.0): base.camera.setZ(  5)
		if (base.camera.getZ() >  45.0): base.camera.setZ( 45)
		self.focus = base.camera.getPos() + (dir*5)
		self.last = task.time
		return Task.cont

t = EulerDemo()

run()
