import sympy


class TupleSymbol(object):
    def __init__(self, letter, *indices):
        name = '%s_%s' % (letter, '_'.join([str(i) for i in indices]))
        self.sym = sympy.Symbol(name, positive=True)
        self.__indices = indices
        self.letter = letter

    def __getitem__(self, index):
        return self.__indices[index]

    def __len__(self):
        return len(self.__indices)

    def __repr__(self):
        return ('TupleSymbol(%s, %s)' % (repr(self.letter),
                ', '.join(str(i) for i in self.__indices)))

    def __hash__(self):
        return hash(repr(self))

    def __eq__(self, o):
        return isinstance(o, TupleSymbol) and repr(self) == repr(o)

    def __ne__(self, o):
        return not self == o


def value(i, j, k):
    return TupleSymbol('V', i, j, k)


def alpha(i, j, k):
    return TupleSymbol('a', i, j, k)


def big_a(i):
    return TupleSymbol('A', i)


def general_alpha(i, j, k):
    return TupleSymbol('a',
                       ''.join(str(c) for c in i),
                       ''.join(str(c) for c in j),
                       ''.join(str(c) for c in k))


def general_product(n, key):
    return TupleSymbol('n', n, ''.join(str(c) for c in key))


def intercept(n, ell):
    return TupleSymbol('X', n, ell)


def general_intercept(n, key):
    return TupleSymbol('X', n, ''.join(str(c) for c in key))


def from_symbol(sym):
    parts = str(sym).split('_')
    letter, indices = parts[0], [int(p) for p in parts[1:]]
    return TupleSymbol(letter, *indices)


q = sympy.Symbol('q', positive=True)
tau = sympy.Symbol('tau', positive=True)
