import matplotlib
matplotlib.use('pdf')
import matplotlib.pyplot as g
from solutions import all_output
from common import value_triples
import solvers


def all_graphics():
    ao = all_output()
    best_by_power_q(ao, (2, 3, 4, 8), 'best_by_power_q')
    best_by_power_q(ao, (2, 3, 4, 5, 8), 'best_by_power_q_5')
    best_by_zero_vars(ao)
    perf_power_zv(ao)


def xmin(seq):
    try:
        return min(seq)
    except ValueError:  # for case of empty sequence
        return None


def best_by_power_q(ao, powers, name):
    g.clf()
    qs = sorted(set(o.aux['search'].q for o in ao))
    plots = {}
    for power in powers:
        best = {
            q: xmin(o.objective * 3.0 for o in ao
                    if o.feasible and
                       o.aux['search'].power == power and
                       o.aux['search'].q == q)
            for q in qs
        }
        plots[power] = g.plot(best.keys(), best.values())[0]
    g.xlabel('$q$')
    g.xticks(qs)
    g.ylabel(r'$\omega$')
    if 5 in powers:
        g.ylim(2.35, 2.8)
    g.legend([plots[power] for power in powers],
             ['power %d' % power for power in powers])
    g.savefig('../notes/paper/%s.pdf' % name, format='pdf')


def best_by_zero_vars(ao):
    g.clf()
    zvs = sorted(set(len(o.aux['search'].zero_vars) for o in ao))
    best = [
        (zv, xmin(o.objective * 3.0 for o in ao
                  if o.feasible and
                     len(o.aux['search'].zero_vars) == zv and
                     o.aux['search'].power == 8))
        for zv in zvs if zv != 0
    ]
    best = [b for b in best if b[1] is not None]
    g.plot([b[0] for b in best], [b[1] for b in best])
    g.xticks([b[0] for b in best])
    g.xlabel('number of zero variables')
    g.ylabel(r'$\omega$')
    g.savefig('../notes/paper/best_by_zero_vars.pdf', format='pdf')


def perf_power_zv(ao):
    FAIL = 'r'
    SUCCESS = 'b'
    power_zv_map = {}
    for o in ao:
        if 'num_calls' not in o.aux: continue
        key = (o.aux['search'].power, len(o.aux['search'].zero_vars))
        if key in power_zv_map:
            power_zv_map[key].append(o)
        else:
            power_zv_map[key] = [o]
    for key in power_zv_map:
        g.clf()
        omegas, calls, feas = zip(*[(o.objective * 3.0, 
                                     o.aux['num_calls'],
                                     SUCCESS if o.feasible else FAIL)
                                    for o in power_zv_map[key]])
        g.scatter(omegas, calls, c=feas,
                  edgecolors='none', alpha=0.5)
        num_vars = len(value_triples(key[0])) - key[1]
        g.title('$\mathcal{P} = %d$, %d zero vars (out of %d)' %
                (key + (num_vars + key[1],)))
        if key[0] == 8:
            xlim = (2.34, 2.44)
        elif key[0] == 5:
            xlim = (2.36, 2.74)
        else:
            xlim = (2.365, 2.405)
        g.plot(xlim, [solvers.DEFAULT_ITERATIONS_RATIO * num_vars ** 2] * 2,
               'r')
        g.xlim(*xlim)
        g.ylim(ymin=0)
        g.xlabel(r'$\omega$')
        g.ylabel(r'NLopt calls')
        g.savefig('../notes/paper/perf_%d_%d.pdf' % key, format='pdf')


if __name__ == '__main__':
    all_graphics()
