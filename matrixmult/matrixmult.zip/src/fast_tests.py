import unittest
from general_test import Test as Test01_GeneralTest
from even_test import Test as Test02_EvenTest
from analysis_test import FastTest as Test03_AnalysisFastTest


if __name__ == '__main__':
    unittest.main()
