import unittest
from sympy import Rational
from sympy import Matrix
import symbols
from symbols import general_intercept as X, general_alpha as a
from symbols import q, tau
import common
from common import test_canonical as canonical
from common import power
import general
from system import LinearSystem


def V(i, j, k):
    return symbols.value(i, j, k).sym


TEST_VALUES = {
    (1, 2, 3): 3 ** Rational(2, 3) * V(0, 1, 1) *
               (1 + V(0, 1, 1) ** 3) ** Rational(1, 3) *
               (6 + V(0, 1, 1) ** 3) ** Rational(1, 3),
}

TEST_NO_CRASH_VALUES = [t for t in common.value_triples(5) if t[0] != 0]


def lp_2_2_2():
    b = a((0, 0, 2), (0, 2, 0), (2, 0, 0))

    def expression():
        return 3 * (1 + V(0, 1, 1) ** 3)

    def free_vars():
        return {(2, 2, 2): {b}}

    def lp_component():
        return 1

    return locals()


def lp_2_2_6():
    b = a((0, 0, 0, 0, 2), (0, 0, 0, 2, 0), (2, 2, 2, 0, 0))

    def expression():
        return (5 * (1 + 2 * V(0, 1, 1) ** 3) ** Rational(2, 3) *
                (2 + 6 * V(0, 1, 1) ** 3 + V(0, 1, 1) ** 6) ** Rational(1, 3))

    def free_vars():
        return {(2, 2, 6): {b}}

    def lp_component():
        return 1

    return locals()


def lp_2_3_5():
    b = a((0, 0, 0, 0, 2),
          (0, 1, 1, 1, 0),
          (2, 1, 1, 1, 0))
    c = a((0, 0, 0, 1, 1),
          (0, 0, 2, 0, 1),
          (2, 2, 0, 1, 0))

    def expression():
        return (5 ** Rational(2, 3) * 2 ** Rational(1, 3) *
                (2 + 1 / V(0, 1, 1) ** 3) ** Rational(1, 3) *
                (1 + 2 / V(0, 1, 1) ** 3) ** Rational(1, 3) *
                (30 * V(0, 1, 1) ** 9 + 20 * V(0, 1, 1) ** 12 +
                 V(0, 1, 1) ** 15) ** Rational(1, 3))

    def free_vars():
        return {(2, 3, 5): {b, c}}

    def lp_component():
        return ((1 / V(0, 1, 1)) **
                (60 * b.sym + 120 * c.sym))
    '''
    def constraints():
        return [
            nx1 / snx - f.sym,
            nz4 / snz - nx1 / snx + f.sym,
            ny0 / sny - nx1 / snx - nz3 / snz + f.sym,
            ny1 / sny - nz4 / snz + nx1 / snx - 2 * f.sym
        ]

    def solution(tau_choice):
        assert tau_choice > 0.767
        return {f.sym: nx1 / snx}
    '''
    return locals()


TEST_LP = {
    (2, 2, 2): lp_2_2_2(),
    (2, 2, 6): lp_2_2_6(),
    (2, 3, 5): lp_2_3_5()
}



class Test(unittest.TestCase):
    def test_general_value(self):
        self.assertEqual(V(0, 0, 2) ** 2 * V(0, 1, 1),
                         general.general_value(((0, 0, 1),
                                                (0, 2, 0),
                                                (2, 0, 1))))
        self.assertEqual(V(0, 1, 1) ** 3,
                         general.general_value(((0, 0, 1),
                                                (1, 1, 0),
                                                (1, 1, 1))))

    def test_linear_system_123(self):
        classes = [((0, 0, 1), (0, 1, 1), (2, 1, 0)),
                   ((0, 0, 1), (0, 2, 0), (2, 0, 1)),
                   ((0, 0, 1), (1, 1, 0), (1, 1, 1))]
        indices = [(0, (0, 0, 1)),
                   (1, (0, 0, 2)),
                   (1, (0, 1, 1)),
                   (2, (0, 1, 2)),
                   (2, (1, 1, 1))]
        expected = LinearSystem(
            [[2, 2, 1],
             [0, 2, 0],
             [2, 0, 1],
             [1, 1, 0],
             [0, 0, 3]],
            [a(*c) for c in classes],
            [X(*i) for i in indices]
        )
        self.assertEqual(expected,
                         general.build_linear_system(classes, indices))

    def test_equivalence_classes_123(self):
        expected = [
            ((0, 0, 1), (0, 2, 0), (2, 0, 1)),
            ((0, 0, 1), (0, 1, 1), (2, 1, 0)),
            ((0, 0, 1), (1, 1, 0), (1, 1, 1)),
        ]
        expected.sort()
        self.assertEqual(expected, general.equivalence_classes((1, 2, 3)))

    def test_coefficient_powers_123(self):
        expected = {
            X(0, (0, 0, 1)): 3 * 1,
            X(1, (0, 1, 1)): 3 * 1,
            X(1, (0, 0, 2)): 3 *
                             general.general_value(((0, 0, 1),
                                                    (0, 2, 0),
                                                    (2, 0, 1))) **
                                 (3 * Rational(6, 3) * Rational(1, 2)) /
                             general.general_value(((0, 0, 1),
                                                    (0, 1, 1),
                                                    (2, 1, 0))) **
                                 (3 * Rational(6, 3) * Rational(1, 2)),
            X(2, (0, 1, 2)): 6 *
                             general.general_value(((0, 0, 1),
                                                    (0, 1, 1),
                                                    (2, 1, 0))) **
                                 (3 * Rational(6, 6) * 1),
            X(2, (1, 1, 1)): 1 *
                             general.general_value(((0, 0, 1),
                                                    (1, 1, 0),
                                                    (1, 1, 1))) **
                                 (3 * Rational(3, 1) * Rational(1, 3)),
        }

        triple = (1, 2, 3)
        classes = general.equivalence_classes(triple)
        indices = general.intercept_indices(classes)
        solved = general.solved_system(classes, indices)
        result = general.coefficient_powers(indices, solved)
        self.assertEqual(expected, result)

    def test_intercept_indices_123(self):
        classes = [
            ((0, 0, 1), (0, 2, 0), (2, 0, 1)),
            ((0, 0, 1), (0, 1, 1), (2, 1, 0)),
            ((0, 0, 1), (1, 1, 0), (1, 1, 1)),
        ]
        expected = (
            [(0, 0, 1)],
            [(0, 0, 2), (0, 1, 1)],
            [(0, 1, 2), (1, 1, 1)],
        )
        self.assertEqual(expected, general.intercept_indices(classes))

    def test_derivatives_matrix_123(self):
        classes = [
            ((0, 0, 1), (0, 2, 0), (2, 0, 1)),
            ((0, 0, 1), (0, 1, 1), (2, 1, 0)),
            ((0, 0, 1), (1, 1, 0), (1, 1, 1)),
        ]
        indices = (
            [(0, 0, 1)],
            [(0, 0, 2), (0, 1, 1)],
            [(0, 1, 2), (1, 1, 1)],
        )
        expected = Matrix([
            [-Rational(1, 2), 1, 0],
            [Rational(1, 2), 0, 0],
            [0, 0, Rational(1, 3)],
        ])
        self.assertEqual(expected,
                         general.solved_system(classes, indices).coefficients)

    def test_products_123(self):
        triple = (1, 2, 3)
        expected = canonical(3 ** Rational(1, 3) *
                             (3 + 3 / V(0, 1, 1) ** 3) ** Rational(1, 3) *
                             (6 * V(0, 1, 1) ** 6 + V(0, 1, 1) ** 9) **
                             Rational(1, 3), power(triple))

        classes = general.equivalence_classes(triple)
        indices = general.intercept_indices(classes)
        solved = general.solved_system(classes, indices)
        products = general.coefficient_powers(indices, solved)
        result = canonical(general.combine_products(products, solved, q, tau),
                           power(triple))
        self.assertEqual(expected, result)

    def test_values(self):
        for triple in TEST_VALUES:
            self.assertEqual(canonical(TEST_VALUES[triple], power(triple)),
                             canonical(general.value(triple), power(triple)))

    def test_no_crash_values(self):
        for triple in TEST_NO_CRASH_VALUES:
            general.value(triple)

    def test_lp(self):
        Q = 5
        TAU = 0.792
        for triple in TEST_LP:
            test = TEST_LP[triple]
            expected = test['expression']() * test['lp_component']()
            result = general.value(triple, recurse=False,
                                   lp_free_vars=test['free_vars']())
            self.assertEqual(canonical(expected, power(triple)),
                             canonical(result, power(triple)))
            '''
            expected = evaluate_8(expected.subs(test['solution'](TAU)),
                                  Q, TAU)
            result = c.value(triple, Q, TAU, recurse=True,
                             lp_free_vars=test['free_vars']())
            self.assertAlmostEqual(1.0, expected / result)
            '''


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
