from sympy import Symbol

from analysis import get_final_program as gfp

from common import value_triples as vts

from symbols import q, tau, alpha

from solvers import solve_cobyla, solve_isres
from solutions import *
from search import Search
