from symbols import q, tau


'''
class Value(object):
    def __init__(self, expression, variables, constraints):
        self.expression = expression
        self.variables = variables
        self.constraints = constraints

    def __eq__(self, other):
        if isinstance(other, Value):
            return (self.expression == other.expression and
                    self.variables == other.variables and
                    self.constraints == other.constraints)

        return False

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return 'Value(\n%s,\n%s,\n%s)' % (repr(self.expression),
                                          repr(self.variables),
                                          repr(self.constraints))
'''


VALUES = {
    (0, 0, 2): 1,
    (0, 1, 1): q ** tau,
    (0, 0, 4): 1,
    (0, 1, 3): (2 * q) ** tau,
    (0, 2, 2): (q ** 2 + 2) ** tau,
}
