import unittest
from sympy import ln
import sympy

import analysis
import even
import solvers
import solutions
from search import Search
from symbols import q, tau, alpha


def program_4():
    triples = [
        (0, 0, 8), (0, 1, 7), (0, 2, 6), (0, 3, 5), (0, 4, 4),
        (1, 1, 6), (1, 2, 5), (1, 3, 4), (2, 2, 4), (2, 3, 3)
    ]
    avars = [a, b, c, d, e, f, g, h, i, j] = [alpha(*triple).sym
                                             for triple in triples]

    ais = [
        2 * (a + b + c + d) + e,
        2 * (b + f + g + h),
        2 * (c + g + i) + j,
        2 * (d + h + j),
        2 * (e + h) + i,
        2 * (d + g),
        2 * c + f,
        2 * b,
        a,
    ]
    left = (4 * ln(q + 2) + sum(ai * ln(ai) for ai in ais))
    perms = [3, 6, 6, 6, 3, 3, 6, 6, 3, 3]
    right = sum(perms[i] * avars[i] * ln(even.value(triples[i]))
                for i in range(len(avars)))
    positive = analysis.canonical(right) - analysis.canonical(left)

    def no_substitute():
        return solvers.Program(
            minimize=tau,
            variables=[tau] + avars,
            positive=[positive],
            lower_bounds=0.0,
            upper_bounds=1.0,
            zero=[
                analysis.canonical((c * h ** 2) ** 6 -  (f * e * j) ** 6),
                analysis.canonical((d * h * i) ** 6 - (e * g * j) ** 6),
                sum(perms[i] * avars[i] for i in range(len(avars))) - 1,
            ]
        )

    def substitute():
        subs_map = {c: f * e * j / h ** 2,
                    d: e * g * j / (h * i)}
        a_sub = (sympy.Rational(1, perms[0]) -
                 sum(sympy.Rational(perms[i], perms[0]) *
                     avars[i].subs(subs_map)
                     for i in range(1, len(avars))))
        subs_map[a] = a_sub
        new_vars = list(set(avars) - set(subs_map.keys()))
        return solvers.Program(
            minimize=tau,
            variables=[tau] + new_vars,
            positive=[positive.subs(subs_map),
                      subs_map[a], subs_map[c], subs_map[d]],
            lower_bounds=0.0,
            upper_bounds=1.0,
            zero=[]
        )

    return {False: no_substitute, True: substitute}
    

class FastTest(unittest.TestCase):
    def test_program_2(self):
        result = analysis.get_final_program(Search(2, q))
        a, b, c, d = (alpha(0, 0, 4).sym, alpha(0, 1, 3).sym,
                      alpha(0, 2, 2).sym, alpha(1, 1, 2).sym)
        r2l = (2 * ln(q + 2) + (2 * (a + b) + c) * ln(2 * (a + b) + c) +
                        2 * (b + d) * ln(2 * (b + d)) +
                        (2 * c + d) * ln(2 * c + d) + 2 * b * ln(2 * b) +
                        a * ln(a))
        r2r = (6 * b * tau * ln(2 * q) + 3 * c * tau * ln(q ** 2 + 2) +
               d * ln(4 * q ** (3 * tau) * (q ** (3 * tau) + 2)))
        expected = solvers.Program(
            minimize=tau,
            variables=[tau, a, b, c, d],
            positive=[
                analysis.canonical(r2r) - analysis.canonical(r2l)
            ],
            lower_bounds=0.0,
            upper_bounds=1.0,
            zero=[
                3 * a + 6 * b + 3 * c + 3 * d - 1,
            ]
        )
        self.assertEqual(expected, result)

    def test_program_4(self):
        free_vars = {alpha(0, 2, 6), alpha(0, 3, 5)}
        result = analysis.get_final_program(Search(4, q, recurse=False,
                                                   free_vars=free_vars))
        expected = program_4()[False]()
        self.assertEqual(expected, result)

    def test_long_short_vars(self):
        triples = [
            (0, 0, 8), (0, 1, 7), (0, 2, 6), (0, 3, 5), (0, 4, 4),
            (1, 1, 6), (1, 2, 5), (1, 3, 4), (2, 2, 4), (2, 3, 3)
        ]
        short_names = 'abcdefghij'
        short_syms = [sympy.Symbol(c, positive=True) for c in short_names]
        long_syms = [alpha(*triple).sym for triple in triples]
        self.assertEqual(dict(zip(long_syms, short_syms)),
                         solutions.short_vars(4))
        self.assertEqual(dict(zip(short_syms, long_syms)),
                         solutions.long_vars(4))

    def test_zero_vars(self):
        '''
        Allow caller of get_final_program to set some of the final variables
        in the optimization to 0 (this special case is necessary to prevent
        nans when calling log).
        '''
        zero_vars = {(0, 0, 4), (0, 1, 3)}
        result = analysis.get_final_program(Search(2, q, zero_vars=zero_vars))
        c, d = (alpha(0, 2, 2).sym, alpha(1, 1, 2).sym)
        r2l = (2 * ln(q + 2) + c * ln(c) + 2 * d * ln(2 * d) +
               (2 * c + d) * ln(2 * c + d))
        r2r = (3 * c * tau * ln(q ** 2 + 2) +
               d * ln(4 * q ** (3 * tau) * (q ** (3 * tau) + 2)))
        expected = solvers.Program(
            minimize=tau,
            variables=[tau, c, d],
            positive=[
                analysis.canonical(r2r) - analysis.canonical(r2l)
            ],
            lower_bounds=0.0,
            upper_bounds=1.0,
            zero=[
                3 * c + 3 * d - 1,
            ]
        )
        self.assertEqual(expected, result)

        search = Search(8, q=5, tau=0.792, zero_vars=solutions.STOC12_P8_ZERO,
                        free_vars=solutions.STOC12_P8_FREE)
        eighth = analysis.get_final_program(search)
        self.assertEqual(11, len(eighth.zero))

    def test_cap_zero_vars(self):
        expected = {(0, 0, 16), (0, 1, 15), (0, 2, 14), (0, 3, 13), (0, 4, 12),
                    (1, 1, 14), (1, 2, 13), (1, 3, 12), (2, 2, 12)}
        self.assertEqual(expected, analysis.cap_zero_vars(8, 11))

    def test_substitute(self):
        free_vars = {alpha(0, 2, 6), alpha(0, 3, 5)}
        result = analysis.get_final_program(Search(4, q, recurse=False,
                                                   substitute=True,
                                                   free_vars=free_vars))
        expected = program_4()[True]()
        self.assertEqual(expected, result)
        
    def test_general_final_program(self):
        analysis.get_final_program(Search(5, q=5, tau=0.792))
        analysis.get_final_program(Search(6, q=5, tau=0.792))
        analysis.get_final_program(Search(7, q=5, tau=0.792))


class SlowTest(unittest.TestCase):
    def test_good_solutions(self):
        for solution in analysis.GOOD_SOLUTIONS:
            if solution['power'] > 4: continue

            program = analysis.get_final_program(Search(solution['power'],
                                                        solution['q'],
                                                        solution['tau']))
            result = solvers.solve_isres(program, solution['random_seed'])
            print(result)
            self.assertTrue(result.feasible)


if __name__ == "__main__":
    unittest.main()
