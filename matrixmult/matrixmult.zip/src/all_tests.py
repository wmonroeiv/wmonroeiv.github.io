import unittest
from fast_tests import *
from analysis_test import SlowTest as Test04_AnalysisSlowTest


if __name__ == '__main__':
    unittest.main()
