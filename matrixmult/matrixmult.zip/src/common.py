from sympy import Rational, Matrix
from sympy import solve, powdenest, factor
from sympy.ntheory import multinomial_coefficients
import itertools
import operator

import symbols


def all_triples(power):
    '''
    Return all variables (with all permutations) for the given power (the
    numbers in a triple for a power must add up to twice that power).
    '''
    return [(i, j, power * 2 - i - j)
            for i in range(0, power * 2 + 1)
            for j in range(0, power * 2 - i + 1)]


def value_triples(power):
    '''
    Return a set of all variables that are suitable for a value V_IJK of the
    specified power.
    '''
    def is_nondecreasing(triple):
        return triple[0] <= triple[1] <= triple[2]

    return [t for t in all_triples(power) if is_nondecreasing(t)]


def power(triple):
    total = sum(triple)
    assert total % 2 == 0, 'Triple should not have odd sum'
    return total / 2


def solve_linear_system(system, variables, intercepts):
    '''
    Solve the system for the variables outside of \\Delta in terms of
    the ones in \\Delta and X_i, Y_j, Z_k. Now we have \\alpha_{ijk} =
    \\alpha_{ijk}([X_i], [Y_j], [X_k], y \\in Delta).

    Return the solution as the Jacobian of the variables in terms of
    the intercepts and the excluded variables, in the order given by
    the list intercepts (which should consist of four elements: X, Y,
    Z, and the triples in \\Delta).
    '''
    print system
    variable_syms = [symbols.value(*triple).sym for triple in variables]
    intercept_syms = [i.sym for i in intercepts]
    solution = solve(system, *(intercept_syms + variable_syms))
    print solution
    solved_set = set(solution.keys())
    solved = sorted(solved_set, key=str)
    excluded = sorted(set(variable_syms) - solved_set, key=str)
    excluded = [symbols.from_symbol(e) for e in excluded]
    vector = [solution[variable] for variable in solved]
    new_intercepts = intercepts + excluded
    new_intercept_syms = [i.sym for i in new_intercepts]
    print new_intercept_syms
    return (new_intercepts, Matrix(vector).jacobian(new_intercept_syms))


def product(factors):
    '''
    Return the product (of multiplication with the * operator, however it may
    be defined) of the elements of the sequence factors.
    '''
    return reduce(operator.mul, factors, 1)


def simplify_step(expr):
    return powdenest(factor(expr ** 3) ** Rational(1, 3), force=True)


def canonical(expr, evalf=False):
    '''
    Simplifies the given expression as much as possible by factoring and
    distributing exponents. This is used to compare two q/tau expressions,
    which can appear in many different equivalent forms and make testing
    difficult if they aren't simplified. If evalf is True, attempt to convert
    the expression to a single floating-point number (note that this will
    destroy the exactness of the expression).

    Assumes both q and tau are positive.
    '''
    if evalf and hasattr(expr, 'evalf'):
        value = expr.evalf()
        try:
            value = float(value)
            return value
        except TypeError:
            pass  # just do normal simplification if evalf doesn't work

    old, expr = expr, simplify_step(expr)
    while old != expr:
        old, expr = expr, simplify_step(expr)
    return expr


def test_canonical(expr, power):
    if hasattr(expr, 'subs'):
        for i in range(2 * power):
            expr = expr.subs(symbols.value(0, 0, i + 1).sym, 1)
    return canonical(expr)


def perm(sym):
    '''
    Return the number of permutations of the sequence sym.
    '''
    groups = tuple(len(tuple(g)) for _k, g in itertools.groupby(sorted(sym)))
    if len(groups) == 0:
        return 1  # (0 choose r) = 1. Wonder why sympy doesn't handle this...
    return multinomial_coefficients(len(groups), len(sym))[groups]
