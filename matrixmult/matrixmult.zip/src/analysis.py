from sympy import log
from sympy import expand

from common import all_triples
from common import value_triples
from common import perm
from common import product
from solvers import Program
from solvers import solve_isres
import symbols
import even
import general
import sympy
import multiprocessing
from system import LinearSystem


def canonical(expr):
    return expand(expand(expr, deep=False), force=True)


def permutations_substitution(perm_constraint):
    a, coeff, perms = perm_constraint
    return {a: perms / coeff}


def permutations_constraint(substitute, avars, deriv_map):
    if substitute:
        deriv_map = derivative_substitution(deriv_map)
    else:
        deriv_map = {}
    a = avars[0]
    avars = avars[1:]
    return (a.sym,
            perm(a),
            1 - sum(perm(s) * (deriv_map[s.sym] if s.sym in deriv_map
                                                else s.sym)
                    for s in avars))


def log_product_of_intercepts(search, large_vars):
    zero_map = {symbols.alpha(i, j, k).sym: 0
                for (i, j, k) in search.zero_vars}
    large_vars = [v.subs(zero_map) for v in large_vars]
    return (search.power * log(search.q + 2) +
            sum(v * log(v) for v in large_vars if v != 0))


def log_product_of_values(search, avars):
    if search.power % 2 == 0 and not search.force_general:
        v = even.value
    else:
        v = general.value

    result = 0
    for var in avars:
        value_expr = v(tuple(var), search.q, search.tau,
                       recurse=search.recurse,
                       lp_free_vars=search.lp_free_vars)
        result += log(value_expr ** (perm(var) * var.sym))
    return result


def inequality_constraints(search, avars, large_vars,
                           deriv_map, perm_constraint):
    lhs = log_product_of_values(search, avars)
    rhs = log_product_of_intercepts(search, large_vars)
    values_constraint = canonical(lhs) - canonical(rhs)  # >= 0
    if search.substitute:
        subs = derivative_substitution(deriv_map)
        subs.update(permutations_substitution(perm_constraint))
        return [values_constraint.subs(subs)] + [subs[v] for v in subs]
    else:
        return [values_constraint]


def derivative_substitution(deriv_map):
    POW, NUM, DENOM = 0, 1, 2
    return {v: (deriv_map[v][NUM] / deriv_map[v][DENOM]) **
               sympy.Rational(1, deriv_map[v][POW])
            for v in deriv_map}


def derivative_map(avars, large_vars, free_vars):
    # Remove one equation because sum_i A_i = 1 is a linear dependency
    lhs = [symbols.big_a(i) for i in range(len(large_vars) - 1)]
    asyms = [a.sym for a in avars]
    coefficients = sympy.Matrix(large_vars[:-1]).jacobian(asyms)
    inverted = LinearSystem(coefficients, avars, lhs).inverted(free_vars)
    included = inverted.intercepts
    excluded = set(inverted.variables) - set(lhs)

    result = {}
    for exc in range(len(inverted.variables)):
        variable = inverted.variables[exc]
        if variable in excluded:
            power = perm(variable)
            numerator = denominator = 1
            for inc in range(len(included)):
                factor = included[inc].sym ** (perm(included[inc]) *
                                               inverted.coefficients[inc, exc])
                if inverted.coefficients[inc, exc] > 0:
                    denominator *= factor
                else:
                    numerator /= factor
            result[variable.sym] = (power, numerator, denominator)
    return result


def derivative_constraints(deriv_map):
    POW, NUM, DENOM = 0, 1, 2
    return [
        v ** deriv_map[v][POW] * deriv_map[v][DENOM] - deriv_map[v][NUM]
        for v in deriv_map
    ]


def equality_constraints(search, avars, deriv_map, perm_constraint):
    if search.substitute:
        return []  # no equality constraints! equality is hard.
    else:
        a, coeff, perms = perm_constraint
        return [coeff * a - perms] + derivative_constraints(deriv_map)


def get_final_program(search):
    avars = [symbols.alpha(i, j, k)
             for (i, j, k) in value_triples(search.power)]
    asyms = [a.sym for a in avars]

    large_vars = [0] * (search.power * 2 + 1)
    for (i, j, k) in all_triples(search.power):
        sorted_var = symbols.alpha(*sorted((i, j, k)))
        large_vars[i] += sorted_var.sym

    deriv_map = derivative_map(avars, large_vars, search.free_vars)
    perm_constraint = permutations_constraint(search.substitute,
                                              avars, deriv_map)
    variables = [asyms[n] for n in range(len(asyms))
                          if tuple(avars[n]) not in search.zero_vars
                             and (not search.substitute or
                                  asyms[n] not in deriv_map and
                                  asyms[n] != perm_constraint[0])]

    return Program(
        minimize=search.tau,
        variables=(variables + [symbols.tau]) if search.tau is symbols.tau
                                              else variables,
        positive=inequality_constraints(search, avars, large_vars,
                                        deriv_map, perm_constraint),
        lower_bounds=0.0,
        upper_bounds=1.0,
        zero=equality_constraints(search, avars, deriv_map, perm_constraint)
    ).subs({symbols.alpha(i, j, k).sym: 0 for (i, j, k) in search.zero_vars},
           evaluate=False)


def cap_zero_vars(power, cap):
    return {triple for triple in value_triples(power)
            if any(e > cap for e in triple)}


GOOD_SOLUTIONS = [
    {'power': 2, 'q': 5, 'tau': 0.791851500606,
     'random_seed': 5716825435493704000},
    {'power': 3, 'q': 5, 'tau': 0.794799215961,
     'random_seed': 2270029299838796926},
    {'power': 4, 'q': 5, 'tau': 0.790923667914,
     'random_seed': 5973488267793578187},
    {'power': 8, 'q': 5, 'tau': 0.790931707283,
     'zero_vars': set([(0, 0, 16), (1, 2, 13), (0, 2, 14),
                       (0, 3, 13), (1, 1, 14), (0, 1, 15)]),
     'random_seed': 562062235114937998},
]

WORLD_RECORD = 0.790886
