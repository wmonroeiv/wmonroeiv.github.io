import math

import sympy
from sympy import Rational
import symbols
from symbols import general_product, general_alpha, general_intercept
from common import product
from common import perm
from common import power
from common import canonical
from system import LinearSystem
import solvers
import even


def general_value(keys, q=symbols.q, tau=symbols.tau,
                  recurse=False, lp_free_vars=None):
    if recurse:
        V = lambda i, j, k: value((i, j, k), q, tau, recurse=True,
                                  lp_free_vars=lp_free_vars)
    else:
        V = lambda i, j, k: symbols.value(i, j, k).sym

    assert len(keys) == 3
    result = 1
    for p in range(len(keys[0])):
        reduced_indices = sorted((int(keys[0][p]),
                                  int(keys[1][p]),
                                  int(keys[2][p])))
        result *= V(*reduced_indices)
    return result


COLUMNS = ((0, 0, 2), (0, 1, 1), (0, 2, 0), (1, 0, 1), (1, 1, 0), (2, 0, 0))


def transpose(columns):
    return tuple(tuple(columns[j][i] for j in range(len(columns)))
                 for i in range(3))


def generate_equiv_classes(width, remaining, curr, result):
    if any(i < 0 for i in remaining):
        return

    if len(curr) == width:
        if remaining == (0, 0, 0):
            result.add(transpose(curr))
        return

    for next_col in COLUMNS:
        if len(curr) != 0 and next_col < curr[-1]:
            continue  # only generate columns in sorted order

        new_remaining = tuple(remaining[i] - next_col[i]
                              for i in range(len(next_col)))
        generate_equiv_classes(width, new_remaining, curr + [next_col], result)


def equivalence_classes(triple):
    '''Compute S^3 for V_{IJK} [triple = (I, J, K)].'''
    width = power(triple)
    classes = set()
    generate_equiv_classes(width, triple, [], classes)
    return sorted(classes)


def general_perm(index):
    assert len(index) == 3 and hasattr(index[0], '__len__')
    zero_indices = [index[1][i] for i in range(len(index[1]))
                                    if int(index[0][i]) == 0]
    one_indices = [index[1][i] for i in range(len(index[1]))
                               if int(index[0][i]) == 1]
    return perm(index[0]) * perm(zero_indices) * perm(one_indices)


def intercept_indices(classes):
    result = (set(), set(), set())
    for i in range(3):
        result[i].update(tuple(sorted(triple[i])) for triple in classes)

    return tuple(sorted(s) for s in result)


def linear_system_coefficient(class_triple, index):
    outer_perm = general_perm(class_triple)
    inner_perm = perm(class_triple[index[0]])
    assert outer_perm % inner_perm == 0
    return outer_perm / inner_perm


def build_linear_system(class_list, index_list):
    coefficients = [[linear_system_coefficient(class_triple, index)
                     if sorted(class_triple[index[0]]) == list(index[1])
                     else 0
                     for class_triple in class_list]
                    for index in index_list]
    class_list = [general_alpha(*c) for c in class_list]
    index_list = [general_intercept(i[0], i[1]) for i in index_list]

    return LinearSystem(coefficients, class_list, index_list)


def solved_system(classes, indices, free=None):
    assert len(indices) == 3
    class_list = sorted(classes)
    indices = (indices[0][:-1], indices[1][:-1], indices[2])
    index_list = []
    for i in range(3):
        index_list += [(i, index) for index in indices[i]]
    return build_linear_system(class_list, index_list).inverted(free)


def coefficient_powers(indices, solved, q=symbols.q, tau=symbols.tau,
                       recurse=False, lp_free_vars=False):
    '''Compute nx, ny, nz for V_ijk, where triple = (i, j, k).'''
    products = {}
    for column, variable in enumerate(solved.variables):
        if len(variable) == 2:
            scale = perm(variable[1])
            exponent = Rational(3, scale)
        else:
            assert len(variable) == 3, variable
            scale = exponent = 1
        curr_product = product(general_value(solved.intercepts[j],
                                             q, tau, recurse, lp_free_vars) **
                               (exponent *
                                general_perm(solved.intercepts[j]) *
                                solved.coefficients[j, column])
                               for j in range(len(solved.intercepts))) * scale
        products[variable] = curr_product

    assert len(indices) == 3
    for n in range(3):
        for index in indices[n]:
            variable = general_intercept(n, index)
            if variable not in products:
                products[variable] = perm(index)

    return products


def product_totals(products):
    totals = [0, 0, 0]
    for variable in products:
        if len(variable) == 2:
            totals[variable[0]] += products[variable]
    return totals


def linear_constraints(solved, products):
    totals = product_totals(products)
    subs = {v: products[v] / (perm(v[1]) * totals[v[0]]) for v in products
                                                         if len(v) == 2}
    return list(solved.coefficients *
                sympy.Matrix([subs[v] if v in subs
                                      else v.sym
                                      for v in solved.variables]))


def solve_excluded(excluded_factors, solved, products, q, tau):
    assert all((len(factor) == 2) for factor in excluded_factors), \
            'invalid format for excluded_factors=%s' % repr(excluded_factors)

    if len(excluded_factors) == 0:
        return 1

    if tau is symbols.tau:
        return product(factor[0] ** factor[1] for factor in excluded_factors)

    log_excluded_factors = sum(factor[1] * sympy.log(factor[0])
                               for factor in excluded_factors)
    minimize = -log_excluded_factors
    variables = sorted(factor[1] for factor in excluded_factors)
    positive = linear_constraints(solved, products) + variables
    program = solvers.Program(minimize, variables, zero=(), positive=positive)
    solution = solvers.solve_pulp(program)
    assert solution.feasible, repr(program)
    return math.exp(-solution.objective)


def combine_products(product_groups, solved, q, tau):
    sums = [0, 0, 0]
    excluded_factors = []
    for variable in product_groups:
        if len(variable) == 2:
            sums[variable[0]] += product_groups[variable]
        else:
            excluded_factors.append((product_groups[variable], variable.sym))

    return canonical(product(s ** Rational(1, 3) for s in sums) *
                     solve_excluded(excluded_factors, solved, product_groups,
                                    q, tau),
                     evalf=isinstance(tau, float))


def value(triple, q=symbols.q, tau=symbols.tau, recurse=False,
          lp_free_vars=None, cache=None):
    r'''
    V_{IJK} >= (\sum_l nx_l)^{1/3} * (\sum_l ny_l)^{1/3} *
               (\sum_l nz_l)^{1/3} *
               \prod_{(i,j,k) \in S^3}
                   V_{i,j,k}^{y*perm(i,j,k)*derivative(alpha_{ijk},y)}

    Cache is ignored, since once you're in the general powers algorithm it
    doesn't help performance much.
    '''
    if triple[0] == 0 and recurse:
        return even.zero_triple(triple, q, tau)

    classes = equivalence_classes(triple)
    indices = intercept_indices(classes)

    if lp_free_vars is not None and triple in lp_free_vars:
        free = lp_free_vars[triple]
    else:
        free = None
    solved = solved_system(classes, indices, free)
    product_groups = coefficient_powers(indices, solved, q, tau, recurse)
    return combine_products(product_groups, solved, q, tau)
