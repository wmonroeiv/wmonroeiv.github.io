import random

from symbols import q, tau
from solvers import Solution
from multiprocessing import Process, Queue, cpu_count

import analysis
import solutions


class Search(object):
    def __init__(self,
                 power,
                 q=q,
                 tau=tau,
                 free_vars=None,
                 lp_free_vars=None,
                 zero_vars=None,
                 recurse=True,
                 substitute=False,
                 force_general=False):
        '''
        Configuration object for starting a matrix multiplication exponent
        search. Configurable parameters include:

            power: which power of the CW algorithm to try (e.g. Williams'
                   STOC'12 paper used 2, 4, and 8).
            q: a free integer parameter of the CW family. Determines the
               rank of the CW construction.
            tau: the value we are trying to minimize (omega <= 3 * tau). The
                 search will attempt to find a solution with the value of tau
                 provided.
            free_vars: the variables to treat as constants (the set S) in the
                       *final program* linear system. [set of TupleSymbols]
            lp_free_vars: the variables to treat as constants (Delta) in each
                          *value* linear system.
            zero_vars: the variables in the final program that are to be
                       artificially set to zero.
            recurse: if True, recursively compute values (instead of leaving
                     them as expressions in terms of lower-power values)
            substitute: if True, substitute the final program equality
                        constraints back into the rest of the program (instead
                        of including them as additional constraints)
            force_general: if True, always use the general powers algorithm
                           for finding values (instead of switching to the
                           even powers algorithm when possible)
        '''
        if zero_vars is None: zero_vars = set()

        params = dict(locals())
        del params['self']
        for param in params:
            setattr(self, param, params[param])
        self.params = params

    def __repr__(self):
        # Woo Python hackery. This just means all the arguments to the Search
        # constructor. Future-proof against additions to this class,
        # although possibly not against future Python versions.
        argc = Search.__init__.func_code.co_argcount
        names = Search.__init__.func_code.co_varnames[1:argc]
        return 'Search(%s)' % ', '.join('%s=%s' % (param, self.params[param])
                                        for param in names)


POWER_DIST = (2, 3, 4, 8)
Q_DIST = (4, 5, 6, 7)
ZERO_VARS_P7 = tuple(analysis.cap_zero_vars(8, n) for n in (9, 10, 11, 12, 13, 14))
ZERO_VARS_P8 = tuple(analysis.cap_zero_vars(8, n) for n in (9, 10, 11, 12))
TAU_RANGE = 0.001
TAU_MEANS = {s['power']: s['tau'] for s in analysis.GOOD_SOLUTIONS}


def random_searches():
    while True:
        power = random.choice(POWER_DIST)
        if power == 8:
            zero_vars = random.choice(ZERO_VARS_P8)
        elif power == 7:
            zero_vars = random.choice(ZERO_VARS_P7)
        else:
            zero_vars = set()
        yield Search(power=power,
                     q=random.choice(Q_DIST),
                     tau=random.uniform(TAU_MEANS[power] - TAU_RANGE,
                                        TAU_MEANS[power] + TAU_RANGE),
                     zero_vars=zero_vars)


def worker(tasks, output):
    from analysis import get_final_program
    from solvers import solve_isres
    import datetime
    while True:
        try:
            search = tasks.get()
            sol = solve_isres(get_final_program(search))
            sol.aux['search'] = search
            sol.aux['timestamp'] = datetime.datetime.now()
            output.put(sol)
        except Exception as e:
            output.put(e)


NUM_PROCESSES = cpu_count()
OUTPUT_TIMEOUT = 3600
TASK_QUOTA = 100

def fill_queue(queue, items, count):
    items = iter(items)
    for i in range(count):
        try:
            queue.put(next(items))
        except StopIteration:
            return i
    return count


OUTPUT_FILE = 'exponents.txt'

def log_entry(entry):
    with open(OUTPUT_FILE, 'a') as log_file:
        log_file.write(entry + '\n')


def output_result(result):
    if isinstance(result, KeyboardInterrupt):
        raise result
    elif isinstance(result, Exception):
        log_entry('!' + repr(result))
        print(result)
    elif isinstance(result, Solution):
        power = result.aux['search'].power
        q = result.aux['search'].q
        omega = result.aux['search'].tau * 3.0
        num_calls = result.aux['num_calls']
        entry = 'power=%s q=%s omega=%s %s' % (repr(power), repr(q),
                                               repr(omega), repr(result))
        log_entry(entry)
        
        gist = 'power=%s q=%s omega=%s num_calls=%s' % (repr(power), repr(q),
                                                        repr(omega),
                                                        repr(num_calls))
        if result.feasible and omega < 3 * analysis.WORLD_RECORD:
            gist = '!!! ' + gist
        elif (result.feasible and power in TAU_MEANS and
              omega < 3 * TAU_MEANS[power]):
            gist = '!   ' + gist
        elif not result.feasible:
            gist = '   (%s)' % gist
        else:
            gist = '    ' + gist
        print(gist)


def distribute(tasks, output_func):
    task_queue = Queue()
    output_queue = Queue()
    processes = [Process(target=worker, args=(task_queue, output_queue))
                 for i in range(NUM_PROCESSES)]

    tasks_out = fill_queue(task_queue, tasks, NUM_PROCESSES)
    tasks_in = 0
    more_tasks = (tasks_out == NUM_PROCESSES)
    for i in range(len(processes)):
        processes[i].start()

    try:
        while True:
            output_func(output_queue.get(block=True, timeout=OUTPUT_TIMEOUT))
            tasks_out -= 1
            tasks_in += 1
            if more_tasks and tasks_in + tasks_out < TASK_QUOTA:
                try:
                    task_queue.put(next(tasks))
                    tasks_out += 1
                except StopIteration:
                    more_tasks = False
            elif tasks_out == 0 or tasks_in >= TASK_QUOTA:
                break
    finally:
        for i in range(len(processes)):
            processes[i].terminate()


if __name__ == '__main__':
    distribute(random_searches(), output_result)

