from sympy import Rational
from sympy.ntheory import multinomial_coefficients as multi
from values import VALUES

from common import all_triples
from common import value_triples
from common import power
from common import product
from common import canonical
from symbols import TupleSymbol, alpha, intercept
import symbols
from system import LinearSystem
import sympy
import solvers
import math
import general


def complement(variable_triple, value_triple):
    return tuple(value_triple[i] - variable_triple[i] for i in range(3))


def variable_triples(power, value_triple):
    '''
    Define variables \\alpha_{ijk} for all good variables i, j, k.
    '''
    def is_valid(triple, value_triple):
        return (triple <= complement(triple, value_triple) and
                all(value_triple[i] >= triple[i] for i in range(3)))

    return [t for t in all_triples(power) if is_valid(t, value_triple)]


def intercept_indices(value_triple):
    '''
    Define variables X_i, Y_j, Z_k for all good variables i, j, k.
    '''
    return (range(value_triple[0] / 2 + 1),
            range(value_triple[1] / 2 + 1),
            range(max(0, value_triple[2] - power(value_triple)),
                  value_triple[2] / 2 + 1))


def linear_system_coefficient(variable, intercept, value_triple):
    result = 0
    if variable[intercept[0]] == intercept[1]:
        result += 1
    if variable[intercept[0]] == value_triple[intercept[0]] - intercept[1]:
        result += 1
    return result


def linear_system(variables, intercepts, value_triple):
    assert not intercepts or isinstance(intercepts[0], TupleSymbol)
    assert not variables or isinstance(variables[0], TupleSymbol)

    intercepts = [i for i in intercepts
                    if i[0] == 2 or
                       i[1] != value_triple[i[0]] / 2]

    coefficients = [[linear_system_coefficient(variable,
                                               intercept,
                                               value_triple)
                     for variable in variables]
                    for intercept in intercepts]

    return LinearSystem(coefficients, variables, intercepts)


def recursive_build_bases(variable_triples, value_triple, q, tau, recurse,
                          lp_free_vars, cache):
    '''
    Let W_{i,j,k} = V_{i,j,k} V_{I-i,J-j,K-k}.
    '''
    if recurse:
        val = lambda triple: (value if power(triple) % 2 == 0
                              else general.value)(triple, q, tau, recurse,
                                                  lp_free_vars, cache)
    else:
        val = lambda triple: symbols.value(*tuple(sorted(triple))).sym

    return {variable_triple: val(variable_triple) *
                             val(complement(variable_triple, value_triple))
            for variable_triple in variable_triples}


def multiply_coefficient_powers(bases, solved, value_triple):
    '''
    Compute for every \\ell,
            nx_\\ell = \\prod_{i,j,k} W_{ijk}^
                {3\\frac{\\partial\\alpha_{ijk}}{\\partial X_\\ell}}
            ny_\\ell = \\prod_{i,j,k} W_{ijk}^
                {3\\frac{\\partial\\alpha_{ijk}}{\\partial Y_\\ell}}
            nz_\\ell = \\prod_{i,j,k} W_{ijk}^
                {3\\frac{\\partial\\alpha_{ijk}}{\\partial z_\\ell}}
    '''
    products = {}
    for column, variable in enumerate(solved.variables):
        if len(variable) == 2 and \
                variable[1] * 2 == value_triple[variable[0]]:
            exponent = 6
            scale = Rational(1, 2)
        elif len(variable) == 2:
            exponent = 3
            scale = 1
        else:
            exponent = 1
            scale = bases[variable]
        curr_product = product(bases[solved.intercepts[j]] **
                               (exponent * solved.coefficients[j, column])
                               for j in range(len(solved.intercepts))) * scale
        products[variable] = curr_product

    # add nx_{\floor{I / 2}} and ny_{\floor{J / 2}}
    products[intercept(0, value_triple[0] / 2)] = \
            Rational(1, 2 - value_triple[0] % 2)
    products[intercept(1, value_triple[1] / 2)] = \
            Rational(1, 2 - value_triple[1] % 2)

    return products


def zero_triple(triple, q, tau):
    coeffs = multi(3, power(triple))

    poly = sum(coeffs[(b, (triple[1] - b) / 2, (triple[2] - b) / 2)] * q ** b
               for b in range(triple[1] % 2, triple[1] + 1, 2))
    return poly ** tau


def product_totals(products):
    totals = [0, 0, 0]
    for variable in products:
        if len(variable) == 2:
            totals[variable[0]] += products[variable]
    return totals


def linear_constraints(solved, products):
    totals = product_totals(products)
    subs = {v: products[v] / totals[v[0]] for v in products
                                          if len(v) == 2}
    return list(solved.coefficients *
                sympy.Matrix([subs[v] if v in subs
                                      else v.sym
                                      for v in solved.variables]))


def solve_excluded(excluded_factors, solved, products, q, tau):
    assert all((len(factor) == 2) for factor in excluded_factors), \
            'invalid format for excluded_factors=%s' % repr(excluded_factors)

    if len(excluded_factors) == 0:
        return 1

    if tau is symbols.tau:
        return product(factor[0] ** factor[1] for factor in excluded_factors)

    log_excluded_factors = sum(factor[1] * sympy.log(factor[0])
                               for factor in excluded_factors)
    minimize = -log_excluded_factors
    variables = sorted(factor[1] for factor in excluded_factors)
    positive = linear_constraints(solved, products) + variables
    program = solvers.Program(minimize, variables, zero=(), positive=positive)
    solution = solvers.solve_pulp(program)
    assert solution.feasible, repr(program)
    return math.exp(-solution.objective)


def combine_products(products, solved, q, tau):
    sums = [0, 0, 0]
    excluded_factors = []
    for variable in products:
        if len(variable) == 2:
            sums[variable[0]] += products[variable]
        else:
            excluded_factors.append((products[variable], variable.sym))
    return canonical(2 * product(s ** Rational(1, 3)
                                 for s in sums) *
                     solve_excluded(excluded_factors, solved, products,
                                    q, tau),
                     evalf=isinstance(tau, float))


def value(value_triple, q=symbols.q, tau=symbols.tau, recurse=False,
          lp_free_vars=None, cache=None):
    '''
    Given a triple (I, J, K), return an expression for the value V_{IJK} in
    terms of the symbols q and tau.
    '''
    if cache is None:
        cache = dict(VALUES)  # make a copy--we'll be adding to this

    value_triple = tuple(sorted(value_triple))
    if value_triple in cache:
        result = cache[value_triple]
        if hasattr(result, 'subs'):
            result = result.subs({symbols.q: q, symbols.tau: tau})
        return result

    if value_triple[0] == 0:
        result = zero_triple(value_triple, q, tau)
        cache[value_triple] = result
        return result

    # 1. Define variables \alpha_{ijk} and X_i, Y_j, Z_k for all good variables
    #    i, j, k.
    smaller_power = sum(value_triple) / 4
    variables = [alpha(*t)
                 for t in variable_triples(smaller_power, value_triple)]
    intercepts = []
    for n, indices in enumerate(intercept_indices(value_triple)):
        intercepts += [intercept(n, ell) for ell in indices]

    # 2. Form the linear system consisting of
    #        X_i = \sum_j \alpha_{ijk},
    #        Y_j = \sum_i \alpha_{ijk}, and
    #        Z_k = \sum_i \alpha_{ijk}.
    # 3. Determine the rank of the system: it is exactly #i + #j + #k - 3
    #    because of the fact that \sum_i X_i = \sum_j Y_j = \sum_k Z_k.
    # 4. If the system does not have full rank, then pick enough variables
    #    \alpha_{ijk} to treat as constants; place them in a set \Delta.
    # 5. Solve the system for the variables outside of \Delta in terms of
    #    the ones in \Delta and X_i, Y_j, Z_k. Now we have \alpha_{ijk} =
    #    \alpha_{ijk}([X_i], [Y_j], [X_k], y \in Delta).
    free = (lp_free_vars[value_triple]
            if lp_free_vars is not None and value_triple in lp_free_vars
            else None)
    solved = linear_system(variables,
                           intercepts,
                           value_triple).inverted(free)

    # 6. Let W_{i,j,k} = V_{i,j,k} V_{I-i,J-j,K-k}. Compute for every \ell,
    #        nx_\ell = \prod_{i,j,k} W_{ijk}^
    #            {3\frac{\partial\alpha_{ijk}}{\partial X_\ell}}
    #        ny_\ell = \prod_{i,j,k} W_{ijk}^
    #            {3\frac{\partial\alpha_{ijk}}{\partial Y_\ell}}
    #        nz_\ell = \prod_{i,j,k} W_{ijk}^
    #            {3\frac{\partial\alpha_{ijk}}{\partial Z_\ell}}
    # 7. Compute for every variable y in \Delta,
    #        ny = \prod_{i,j,k} W_{ijk}^
    #            {\frac{\partial\alpha_{ijk}}{\partial y}}
    bases = recursive_build_bases(variables, value_triple, q, tau, recurse,
                                  lp_free_vars, cache)
    products = multiply_coefficient_powers(bases, solved, value_triple)

    # 8. Compute for each \alpha_{ijk} its setting \alpha_{ijk}(\Delta) as a
    #    function of the y in \Delta when X_\ell = nx_\ell/\sum_i nx_i,
    #    Y_\ell = ny_\ell/sum_j ny_j, and Z_\ell = nz_\ell/sum_k nz_k.
    # 9. Then set
    #        VIJK = 2 (\sum_\ell nx_\ell)^{1/3}(\sum_\ell ny_\ell)^{1/3}
    #                 (\sum_\ell nz_\ell)^{1/3} \prod_{y \in \Delta} ny^y.
    #    subject to the constraints on y in \Delta given by
    #        y \geq 0 for all y in \Delta,
    #        \alpha_{ijk}(\Delta) \geq 0 for every \alpha_{ijk} \notin \Delta.
    result = combine_products(products, solved, q, tau)
    cache[value_triple] = result
    return result


def all_values(power):
    '''
    Determines values V_{IJK} for the given power of the matrix
    multiplication algorithm framework in Williams, STOC'12.

    This version uses the specialized algorithm for even powers.
    '''
    assert power % 2 == 0, 'Power is not even'

    result = {}
    for triple in value_triples(power):
        try:
            result[triple] = value(triple)
        except KeyError, e:
            result[triple] = ('[could not solve linear system for %s]' %
                              str(e))
    return result


def print_values():
    '''
    Prints all values V_{IJK} for tensor powers 1, 2, and 4.
    '''
    for power in (2, 4, 8):
        print('Power %d' % power)
        values = all_values(power)
        for triple in sorted(values.keys()):
            print('    %s: %s' % (str(triple), str(values[triple])))
        print('')


if __name__ == '__main__':
    print_values()
