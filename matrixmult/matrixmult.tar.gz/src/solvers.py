"""
Defines classes to represent linear and nonlinear programs and submit those
programs to solvers (currently solves nonlinearly using NLOpt).
"""
import random
import sys
import nlopt
import pulp
import sympy
import numbers


class Solution(object):
    def __init__(self, vars_map, objective, result, feasible=True, aux=None):
        self.objective = objective
        self.result = result
        self.vars_map = vars_map
        self.feasible = feasible
        self.aux = aux

    def get(self, var):
        return self.vars_map[var]

    def __repr__(self):
        return ('Solution(vars_map=%s, objective=%s, ' +
                'result=%s, feasible=%s, aux=%s)') % (
            repr(self.vars_map), repr(self.objective),
            repr(self.result), repr(self.feasible), repr(self.aux)
        )


def is_variable(expr):
    return isinstance(expr, sympy.Symbol)


class Program(object):
    def __init__(self, minimize, variables=(), zero=(), positive=(),
                 lower_bounds=-float('inf'), upper_bounds=float('inf')):
        self.minimize = minimize
        self.variables = sorted(set(variables), key=str)
        self.zero = set(z for z in zero if z != 0)
        self.positive = set(positive)
        self.lower_bounds = lower_bounds
        self.upper_bounds = upper_bounds

    def subs(self, vars_map, evaluate=True):
        return Program(minimize=self.subs_expr(self.minimize,
                                               vars_map, evaluate),
                       variables=self.new_variables(vars_map),
                       zero=[self.subs_expr(expr, vars_map, evaluate)
                             for expr in self.zero], 
                       positive=[self.subs_expr(expr, vars_map, evaluate)
                                 for expr in self.positive],
                       lower_bounds=self.lower_bounds,
                       upper_bounds=self.upper_bounds)

    def new_variables(self, vars_map):
        subbed = [(vars_map[v] if v in vars_map else v)
                  for v in self.variables]
        return [expr for expr in subbed if is_variable(expr)]

    def subs_expr(self, expr, vars_map, evaluate):
        if hasattr(expr, 'subs'):
            result = expr.subs(vars_map)
            return result.evalf() if evaluate else result
        else:
            return expr

    def __eq__(self, other):
        if not isinstance(other, Program):
            return False

        for name in ('minimize', 'variables', 'zero', 'positive'):
            if getattr(self, name) != getattr(other, name):
                return False
        return True

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return ('Program(minimize=%s, variables=%s, zero=%s, ' +
                'positive=%s)') % (repr(self.minimize),
                                  repr(self.variables),
                                  repr(self.zero),
                                  repr(self.positive))


DEFAULT_OBJECTIVE_TOLERANCE = 1e-8
DEFAULT_CONSTRAINT_TOLERANCE = 1e-8
DEFAULT_MAX_TIME = None  # value in sec for time limiting
DEFAULT_MAX_ITERATIONS = 1000000
DEFAULT_ITERATIONS_RATIO = 20000  # * |variables|**2 = max_iterations
DEFAULT_STOPPING_GRANULARITY = 10000
DEFAULT_STOPPING_COUNT = 1

FAIL = 1.0


class NLoptSolver(object):
    def __init__(self, program, algorithm, guesses=None,
                 objective_tol=DEFAULT_OBJECTIVE_TOLERANCE,
                 constraint_tol=DEFAULT_CONSTRAINT_TOLERANCE,
                 max_time=DEFAULT_MAX_TIME,
                 max_iterations=DEFAULT_MAX_ITERATIONS,
                 stopping_granularity=DEFAULT_STOPPING_GRANULARITY,
                 stopping_count=DEFAULT_STOPPING_COUNT,
                 random_seed=None, verbose=False):
        if guesses is None:
            guesses = [1e-4] * len(program.variables)
        else:
            guesses = list(guesses)

        if random_seed is None:
            random_seed = random.randint(0, sys.maxint)  # TODO

        assert len(guesses) == len(program.variables), (
                'got %d guesses for %d variables'
            ) % (len(guesses), len(program.variables))
        (self.program,
         self.algorithm,
         self.guesses,
         self.objective_tol,
         self.constraint_tol,
         self.max_time,
         self.max_iterations,
         self.stopping_granularity,
         self.stopping_count,
         self.random_seed,
         self.verbose) = (program,
                          algorithm,
                          guesses,
                          objective_tol,
                          constraint_tol,
                          max_time,
                          max_iterations,
                          stopping_granularity,
                          stopping_count,
                          random_seed,
                          verbose)

    def solve(self):
        opt = self.init_opt()
        self.last_x = self.guesses
        self.last_objective = self.min_lambda(self.guesses, monitor=False)
        try:
            opt.optimize(self.guesses)
        except StopIteration:
            pass
        return self.get_solution(opt)

    # Implementation helper methods
    def init_opt(self):
        self.init_functions()
        opt = nlopt.opt(self.algorithm, len(self.program.variables))
        opt.set_min_objective(self.min_lambda)

        for zero in self.zero_lambdas:
            opt.add_equality_constraint(zero, self.constraint_tol)
        for negative in self.negative_lambdas:
            opt.add_inequality_constraint(negative, self.constraint_tol)

        opt.set_ftol_rel(self.objective_tol)
        if self.max_time is not None:
            opt.set_maxtime(self.max_time)
        opt.set_lower_bounds(self.program.lower_bounds)
        opt.set_upper_bounds(self.program.upper_bounds)
        nlopt.srand(self.random_seed)
        return opt

    def init_functions(self):
        self.min_lambda = self.lambdify(self.evalf(self.program.minimize))
        self.zero_lambdas = [self.lambdify(self.evalf(z))
                             for z in self.program.zero]
        # Use negative because nlopt uses f(x) <= 0
        self.negative_lambdas = [self.lambdify(self.evalf(-p))
                                 for p in self.program.positive]

    def evalf(self, expr):
        if hasattr(expr, 'evalf'):
            return expr.evalf()
        else:
            return expr

    def lambdify(self, expr):
        lambdified = sympy.lambdify(self.program.variables, expr)
        self.num_calls = 0
        self.curr_stopping_count = 0

        def monitoring_func(x, _grad=None, monitor=True):
            if monitor:
                self.last_x = x
                if self.num_calls % self.stopping_granularity == 0:
                    if self.num_calls >= self.max_iterations:
                        raise StopIteration
                    if self.meets_stopping_condition(x):
                        self.curr_stopping_count += 1
                        if self.curr_stopping_count >= self.stopping_count:
                            raise StopIteration
                    else:
                        self.curr_stopping_count = 0
                self.num_calls += 1
            try:
                return float(lambdified(*x))
            except ValueError:
                # don't grind to a halt if we accidentally call log(0)
                return FAIL
        return monitoring_func

    def is_feasible(self, x):
        zeros = [zl(x, monitor=False) for zl in self.zero_lambdas]
        inequalities = [nl(x, monitor=False) for nl in self.negative_lambdas]
        if self.verbose:
            print('zero = %s' % repr(zeros))
            print('negative = %s' % repr(inequalities))
        return (all(abs(z) < self.constraint_tol for z in zeros) and
                all(n <= 0 for n in inequalities))

    def meets_stopping_condition(self, x):
        objective = self.min_lambda(x, monitor=False)
        result = (self.is_feasible(x) and
                  abs((objective - self.last_objective) / objective) <
                  self.objective_tol)
        self.last_objective = objective
        return result

    def get_solution(self, opt):
        final_vector = self.last_x
        final_objective = self.min_lambda(final_vector, monitor=False)
        vars_map = {v: final_vector[i]
                    for (i, v) in enumerate(self.program.variables)}
        feasible = self.is_feasible(final_vector)
        return Solution(vars_map=vars_map,
                        objective=final_objective,
                        result=opt.last_optimize_result(),
                        feasible=feasible,
                        aux={'random_seed': self.random_seed,
                             'num_calls': self.num_calls})


class PuLPSolver(object):
    def __init__(self, program, output=False):
        self.program = program
        self.output = output
        self.pulp_variables = None

    def solve(self):
        problem = pulp.LpProblem(sense=pulp.LpMinimize)
        problem += self.pulpify(self.program.minimize)
        for bound in self.program.positive:
            problem += (self.pulpify(bound) >= 0)
        for constraint in self.program.zero:
            problem += (self.pulpify(constraint) == 0)
        problem.solve(pulp.GLPK(msg=self.output))
        return self.assemble_solution(problem)

    def pulpify(self, expr):
        lambdified = sympy.lambdify(self.program.variables, expr.evalf())
        if self.pulp_variables is None:
            self.pulp_variables = [pulp.LpVariable(v.name)
                                   for v in self.program.variables]
        return lambdified(*self.pulp_variables)

    def assemble_solution(self, problem):
        names = [v.name for v in self.pulp_variables]
        vars_map = {self.program.variables[names.index(v.name)]:
                    v.varValue
                    for v in problem.variables()}
        objective = pulp.value(problem.objective)
        if objective is None:
            assert isinstance(self.program.minimize, numbers.Number) or \
                    isinstance(self.program.minimize, sympy.Number)
            objective = float(self.program.minimize)
        result = problem.status
        return Solution(vars_map, objective, result,
                        feasible=(pulp.LpStatus[result] == 'Optimal'))


def solve_isres(program, random_seed=None, verbose=False):
    return NLoptSolver(program, nlopt.GN_ISRES,
                       random_seed=random_seed,
                       verbose=verbose,
                       max_iterations=DEFAULT_ITERATIONS_RATIO *
                                      len(program.variables) ** 2).solve()


def solve_cobyla(program, starting_point, random_seed=None, verbose=False):
    guesses = [starting_point[v] for v in program.variables]
    return NLoptSolver(program, nlopt.LN_COBYLA,
                       random_seed=random_seed,
                       verbose=verbose,
                       guesses=guesses).solve()


def solve_pulp(program, output=False):
    return PuLPSolver(program, output).solve()
