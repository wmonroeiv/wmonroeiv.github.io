'''
Tests the even module by verifying that output of all functions is
correct for cases enumerated by Williams (in email or in STOC'12).
'''

from sympy import Rational
import symbols
from symbols import q, tau, alpha
import even as c
import unittest
import abc
from common import value_triples


def V(i, j, k):
    return symbols.value(i, j, k).sym


TEST_REC = {
    # 2nd power
    (1, 1, 2): (2 ** Rational(2, 3) * (q ** tau) *
                (q ** (3 * tau) + 2) ** Rational(1, 3)),

    # 4th power
    (1, 1, 6): (2 ** Rational(2, 3) *
                (8 * q ** (3 * tau) * (q ** (3 * tau) + 2) +
                 (2 * q) ** (6 * tau)) ** Rational(1, 3)),
    (1, 2, 5): (2 ** Rational(2, 3) *
                (2 * (q ** 2 + 2) ** (3 * tau) +
                 (4 * q ** (3 * tau) * (q ** (3 * tau) + 2))) **
                 Rational(1, 3) *
                 ((4 * q ** (3 * tau) * (q ** (3 * tau) + 2)) /
                 (q ** 2 + 2) ** (3 * tau) + (2 * q) ** (3 * tau)) **
                 Rational(1, 3)),
    (1, 3, 4): (2 ** Rational(2, 3) *
                ((2 * q) ** (3 * tau) +
                 4 * q ** (3 * tau) * (q ** (3 * tau) + 2)) **
                Rational(1, 3) *
                (2 + 2 * (2 * q) ** (3 * tau) +
                 (q ** 2 + 2) ** (3 * tau)) ** Rational(1, 3)),
}

TEST_NO_REC = {
    # 4th power
    (2, 2, 4): ((2 * V(0, 2, 2) ** 3 + V(1, 1, 2) ** 3) ** Rational(2, 3) *
                 (2 + 2 * V(0, 1, 3) ** 3 +
                  V(0, 2, 2) ** 3) ** Rational(1, 3) / V(0, 2, 2)),

    # 8th power
    (1, 1, 14): (2 ** Rational(2, 3) *
                 (2 * V(1, 1, 6) ** 3 + V(0, 1, 7) ** 6) ** Rational(1, 3)),
    (1, 2, 13): (2 ** Rational(2, 3) *
                 (V(1, 1, 6) ** 3 + 2 * V(0, 2, 6) ** 3) ** Rational(1, 3) *
                 ((V(1, 2, 5) / V(0, 2, 6)) ** 3 + V(0, 1, 7) ** 3) **
                 Rational(1, 3)),
    (1, 3, 12): (2 * (V(0, 3, 5) ** 3 / V(1, 2, 5) ** 3 + 1) **
                 Rational(1, 3) *
                 (V(1, 3, 4) ** 3 * V(1, 2, 5) ** 3 / V(0, 3, 5) ** 3 +
                  V(0, 1, 7) ** 3 * V(1, 2, 5) ** 3 +
                  V(0, 2, 6) ** 3 * V(1, 1, 6) ** 3 / 2) ** Rational(1, 3)),
    (1, 4, 11): (2 * (V(0, 4, 4) ** 3 / V(1, 3, 4) ** 3 + 1 +
                      V(0, 2, 6) ** 3 * V(1, 2, 5) ** 3 /
                      (2 * V(0, 3, 5) ** 3 * V(1, 1, 6) ** 3)) **
                 Rational(1, 3) *
                 (V(1, 3, 4) ** 6 / V(0, 4, 4) ** 3 +
                  V(0, 1, 7) ** 3 * V(1, 3, 4) ** 3 +
                  V(0, 3, 5) ** 3 * V(1, 1, 6) ** 3) ** Rational(1, 3)),
    (1, 5, 10): (2 * (V(0, 3, 5) ** 3 / V(1, 3, 4) ** 3 + 1 +
                      V(0, 2, 6) ** 3 * V(1, 3, 4) ** 3 /
                      (V(0, 4, 4) ** 3 * V(1, 1, 6) ** 3)) **
                 Rational(1, 3) *
                 (V(1, 2, 5) ** 3 * V(1, 3, 4) ** 3 / V(0, 3, 5) ** 3 +
                  V(0, 1, 7) ** 3 * V(1, 3, 4) ** 3 +
                  V(0, 4, 4) ** 3 * V(1, 1, 6) ** 3 +
                  V(0, 3, 5) ** 3 * V(1, 2, 5) ** 3 *
                  V(0, 4, 4) ** 3 * V(1, 1, 6) ** 3 /
                  (2 * V(0, 2, 6) ** 3 * V(1, 3, 4) ** 3)) ** Rational(1, 3)),
    (1, 6, 9): (2 * (V(0, 2, 6) ** 3 / V(1, 2, 5) ** 3 + 1 +
                     V(0, 2, 6) ** 3 * V(1, 3, 4) ** 3 /
                     (V(0, 3, 5) ** 3 * V(1, 1, 6) ** 3) +
                     V(1, 3, 4) ** 6 * V(0, 2, 6) ** 3 /
                     (2 * V(0, 4, 4) ** 3 * V(1, 2, 5) ** 3 *
                     V(1, 1, 6) ** 3)) ** Rational(1, 3) *
                (V(1, 1, 6) ** 3 * V(1, 2, 5) ** 3 / V(0, 2, 6) ** 3 +
                 V(0, 1, 7) ** 3 * V(1, 2, 5) ** 3 +
                 V(0, 3, 5) ** 3 * V(1, 1, 6) ** 3 +
                 V(0, 4, 4) ** 3 * V(1, 2, 5) ** 3 *
                 V(0, 3, 5) ** 3 * V(1, 1, 6) ** 3 /
                 (V(0, 2, 6) ** 3 * V(1, 3, 4) ** 3)) ** Rational(1, 3)),
    (1, 7, 8): (2 * (V(0, 1, 7) ** 3 + V(1, 1, 6) ** 3 +
                     V(1, 2, 5) ** 3 + V(1, 3, 4) ** 3) ** Rational(1, 3) *
                (1 + V(0, 1, 7) ** 3 + V(0, 2, 6) ** 3 +
                 V(0, 3, 5) ** 3 + V(0, 4, 4) ** 3 / 2) ** Rational(1, 3)),
    (2, 2, 12): (2 * (V(0, 2, 6) ** 3 / V(1, 1, 6) ** 3 +
                      Rational(1, 2)) ** Rational(1, 3) *
                 (V(0, 1, 7) ** 3 * V(1, 2, 5) ** 3 * V(0, 2, 6) ** 3 /
                  V(1, 1, 6) ** 3 +
                  V(0, 1, 7) ** 3 * V(1, 2, 5) ** 3 / 2) ** Rational(1, 3) *
                 (V(2, 2, 4) ** 3 * V(1, 1, 6) ** 6 /
                  (V(0, 1, 7) ** 3 * V(1, 2, 5) ** 3 * V(0, 2, 6) ** 6) +
                  V(1, 1, 6) ** 3 / V(0, 2, 6) ** 3 +
                  V(1, 1, 6) ** 6 /
                  (2 * V(0, 1, 7) ** 3 * V(1, 2, 5) ** 3)) ** Rational(1, 3))
}

TEST_ZEROES = {
    # 1st power
    (0, 0, 2): 1,
    (0, 1, 1): q ** tau,

    # 2nd power
    (0, 0, 4): 1,
    (0, 1, 3): (2 * q) ** tau,
    (0, 2, 2): (q ** 2 + 2) ** tau,

    # 4nd power
    (0, 0, 8): 1,
    (0, 1, 7): (4 * q) ** tau,
    (0, 2, 6): (4 + 6 * q ** 2) ** tau,
    (0, 3, 5): (12 * q + 4 * q ** 3) ** tau,
    (0, 4, 4): (6 + 12 * q ** 2 + q ** 4) ** tau,

    # 8nd power
    (0, 0, 16): 1,
    (0, 1, 15): (8 * q) ** tau,
    (0, 2, 14): (8 + 28 * q ** 2) ** tau,
    (0, 3, 13): (56 * q + 56 * q ** 3) ** tau,
    (0, 4, 12): (70 * q ** 4 + 168 * q ** 2 + 28) ** tau,
    (0, 5, 11): (280 * q ** 3 + 168 * q + 56 * q ** 5) ** tau,
    (0, 6, 10): (56 + 420 * q ** 2 + 280 * q ** 4 + 28 * q ** 6) ** tau,
    (0, 7, 9): (280 * q + 560 * q ** 3 + 168 * q ** 5 + 8 * q ** 7) ** tau,
    (0, 8, 8): (70 + 560 * q ** 2 + 420 * q ** 4 +
                56 * q ** 6 + q ** 8) ** tau,
}


def evaluate_8(expr, q_choice, tau_choice):
    return float(expr.subs({V(*triple): c.value(triple, q_choice,
                                                tau_choice, recurse=True)
                            for triple in value_triples(4)}).evalf())


def lp_2_3_11():
    f = alpha(1, 1, 6)

    nx0 = 1
    nx1 = (V(1, 3, 4) ** 3 * V(1, 2, 5) ** 3 /
           (2 * V(0, 3, 5) ** 3 * V(2, 2, 4) ** 3))
    snx = nx0 + nx1

    ny0 = V(0, 3, 5) ** 3 * V(0, 2, 6) ** 3
    ny1 = V(0, 2, 6) ** 3 * V(1, 2, 5) ** 3
    sny = ny0 + ny1

    nz3 = V(2, 3, 3) ** 3 / (V(0, 3, 5) * V(0, 2, 6)) ** 3
    nz4 = ((V(0, 1, 7) * V(2, 2, 4)) / (V(0, 2, 6) * V(1, 2, 5))) ** 3
    nz5 = 1
    snz = nz3 + nz4 + nz5

    def expression():
        return 2 * (snx ** Rational(1, 3) *
                    sny ** Rational(1, 3) *
                    snz ** Rational(1, 3))

    def free_vars():
        return {(2, 3, 11): {f}}

    def lp_component():
        return (((V(1, 1, 6) * V(2, 2, 4) * V(0, 3, 5)) /
                 (V(1, 3, 4) * V(0, 2, 6) * V(1, 2, 5))) **
                alpha(1, 1, 6).sym)

    def constraints():
        return [
            nx1 / snx - f.sym,
            nz4 / snz - nx1 / snx + f.sym,
            ny0 / sny - nx1 / snx - nz3 / snz + f.sym,
            ny1 / sny - nz4 / snz + nx1 / snx - 2 * f.sym
        ]

    def solution(tau_choice):
        assert tau_choice > 0.767
        return {f.sym: nx1 / snx}

    return locals()


def lp_2_5_9():
    g = alpha(1, 0, 7)
    j = alpha(1, 2, 5)

    nx0 = ((V(0, 4, 4) * V(1, 2, 5) * V(0, 2, 6) * V(2, 3, 3)) /
           (V(0, 3, 5) * V(2, 2, 4))) ** 3
    nx1 = (V(1, 1, 6) * V(1, 3, 4)) ** 3 / 2
    snx = nx0 + nx1

    ny0 = ((V(0, 3, 5) ** 2 * V(2, 2, 4)) /
           (V(2, 3, 3) * V(0, 4, 4) * V(1, 2, 5))) ** 3
    ny1 = 1
    ny2 = ((V(0, 3, 5) * V(2, 2, 4)) / (V(0, 4, 4) * V(1, 2, 5))) ** 3
    sny = ny0 + ny1 + ny2

    nz1 = (V(1, 2, 5) / (V(0, 3, 5) * V(0, 2, 6))) ** 3
    nz2 = ((V(0, 1, 7) * V(2, 2, 4) ** 2 * V(0, 3, 5)) /
           (V(0, 2, 6) * V(2, 3, 3) * V(0, 4, 4) * V(1, 2, 5))) ** 3
    nz3 = 1
    nz4 = ((V(0, 3, 5) * V(2, 2, 4)) /
           (V(0, 2, 6) * V(2, 3, 3))) ** 3
    snz = nz1 + nz2 + nz3 + nz4

    def expression():
        return 2 * (snx ** Rational(1, 3) *
                    sny ** Rational(1, 3) *
                    snz ** Rational(1, 3))

    def free_vars():
        return {(2, 5, 9): {g, j}}

    def lp_component():
        return (((V(0, 4, 4) ** 2 * V(1, 2, 5) ** 3 *
                  V(0, 2, 6) * V(2, 3, 3) ** 2) /
                 (V(0, 3, 5) ** 3 * V(2, 2, 4) ** 3 *
                  V(1, 1, 6) * V(1, 3, 4))) ** g.sym *
                ((V(0, 2, 6) * V(2, 3, 3) * V(0, 4, 4) * V(1, 2, 5) ** 2) /
                 (V(0, 3, 5) ** 2 * V(2, 2, 4) **
                  2 * V(1, 1, 6))) ** j.sym)

    def constraints():
        return [
            nz2 / snz - g.sym,
            2 * g.sym + j.sym + nx0 / snx - (ny0 + ny2) / sny - nz2 / snz,
            2 * g.sym + j.sym + nx0 / snx - ny0 / sny - (nz2 + nz4) / snz,
            nx0 / snx + (ny0 + ny2) / sny + (nz2 + nz4) / snz - 2 * g.sym -
                2 * j.sym,
            ny0 / sny - nz1 / snz - g.sym,
            nx1 / snx - g.sym - j.sym,
        ]

    def solution(tau_choice):
        assert tau_choice > 0.767
        return {g.sym: nz2 / snz,
                j.sym: (nz4 - nz2) / snz - nx0 / snx + ny0 / sny}

    return locals()


TEST_LP = {
    (2, 3, 11): lp_2_3_11(),
    (2, 5, 9): lp_2_5_9(),
}


class Test(unittest.TestCase):  # IGNORE:R0904 too many public methods
    def test_no_recurse(self):
        for triple in TEST_NO_REC:
            expected = TEST_NO_REC[triple]
            result = c.value(triple, recurse=False)
            self.assertEqual(self.canonical(expected, triple),
                             self.canonical(result, triple))

    def test_recurse(self):
        for triple in TEST_REC:
            expected = TEST_REC[triple]
            result = c.value(triple, recurse=True)
            self.assertEqual(self.canonical(expected, triple),
                             self.canonical(result, triple))

    def test_lp(self):
        Q = 5
        TAU = 0.792
        for triple in TEST_LP:
            test = TEST_LP[triple]
            expected = test['expression']() * test['lp_component']()
            result = c.value(triple, recurse=False,
                             lp_free_vars=test['free_vars']())
            self.assertEqual(self.canonical(expected, triple),
                             self.canonical(result, triple))

            expected = evaluate_8(expected.subs(test['solution'](TAU)),
                                  Q, TAU)
            result = c.value(triple, Q, TAU, recurse=True,
                             lp_free_vars=test['free_vars']())
            self.assertAlmostEqual(1.0, expected / result)

    def test_zeroes(self):
        for triple in TEST_ZEROES:
            expected = TEST_ZEROES[triple]
            result = c.zero_triple(triple, q, tau)
            self.assertEqual(expected, result)

    def canonical(self, expr, triple):
        if isinstance(expr, abc.types.ListType):
            return set(self.canonical(e, triple) for e in expr)

        power = c.power(triple)
        curr = 1
        while curr < power:
            expr = expr.subs({V(0, 0, 2 * curr): 1})
            curr *= 2
        return c.canonical(expr)


if __name__ == "__main__":
    unittest.main()
