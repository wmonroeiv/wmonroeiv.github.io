import even
print(even.value((2, 2, 8), q=5, tau=0.792))
