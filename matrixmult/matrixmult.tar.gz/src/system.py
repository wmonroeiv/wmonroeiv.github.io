import sympy
from sympy import Matrix
from sympy import ShapeError


class LinearSystem(object):
    '''
    A system of linear equations of the form Ax = b, where A (the
    "coefficients") is a matrix, and x (the "variables") and b (the
    "intercepts") are vectors.
    '''

    def __init__(self, coefficients, variables, intercepts):
        self.coefficients = Matrix(coefficients)
        self.variables = list(variables)
        self.intercepts = list(intercepts)

        if self.coefficients.cols != len(variables):
            raise ShapeError('Number of columns of coefficients should ' +
                             'equal number of variables')
        if self.coefficients.rows != len(intercepts):
            raise ShapeError('Number of rows of coefficients should ' +
                             'equal number of intercepts')

    def inverted(self, free=None):
        '''
        Solve the linear system for the variables in terms of the intercepts,
        if possible. If the system is not of full rank, solve for an
        arbitrarily chosen subset of the variables in terms of the intercepts
        and the remaining variables. Return the solved system as a
        LinearSystem object.

        The parameter free allows one to control the arbitrary choice of
        variables; free, if not None, should be a subset of self.variables
        that should be *remaining* ("free") in the inverted system.
        '''
        if free is None:
            pivots = set(self.coefficients.rref()[1])
        else:
            self.check_free_vars(free)
            pivots = set(col for col in range(self.coefficients.cols)
                             if self.variables[col] not in free)
        assert len(pivots) <= self.coefficients.rows, \
                '%s; free=%s' % (repr(self), repr(free))
        for col in range(self.coefficients.cols):
            if len(pivots) == self.coefficients.rows:
                break
            pivots.add(col)
        pivots = sorted(pivots)
        included_cols = Matrix([[]] * self.coefficients.rows)
        included_vars = []
        excluded_cols = Matrix(self.coefficients)
        excluded_vars = list(self.variables)
        for col in pivots:
            included_cols = included_cols.row_join(self.coefficients[:,col])
            included_vars.append(self.variables[col])
        for col in reversed(pivots):
            excluded_cols.col_del(col)
            del excluded_vars[col]

        assert included_cols.cols == included_cols.rows
        width = included_cols.cols
        return LinearSystem(included_cols.inv() *
                            (sympy.eye(width).row_join(-excluded_cols)),
                            self.intercepts + excluded_vars, included_vars)

    def check_free_vars(self, free):
        for v in free:
            if v not in self.variables:
                raise KeyError(v)

    def __eq__(self, other):
        '''
        A very strict test for equality--requires that the form of two systems
        be exactly equal. Some time in the future we may want to replace this
        with some sort of equivalence testing.
        '''
        if isinstance(other, LinearSystem):
            return (self.coefficients == other.coefficients and
                    self.variables == other.variables and
                    self.intercepts == other.intercepts)

        return False

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return 'LinearSystem(\n%s,\n%s,\n%s)' % (repr(self.coefficients),
                                                 repr(self.variables),
                                                 repr(self.intercepts))
